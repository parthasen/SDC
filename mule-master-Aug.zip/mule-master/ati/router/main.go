package main

import (
	"ati/schema"
	"github.com/chzyer/readline"
	zmq "github.com/pebbe/zmq4"

	"log"
	"os"
)

func main() {
	log.SetPrefix("[orchestrator] ")

	ready := make(chan int)

	go proxy(ready)
	<- ready

	publisher()
}

func proxy(ready chan int) {
	pub := os.Getenv("ATI_PUB")
	sub := os.Getenv("ATI_SUB")

	frontend, _ := zmq.NewSocket(zmq.XSUB)
	defer frontend.Close()

	if err := frontend.Bind(pub); err != nil {
		log.Fatalf("Unable to open XSUB socket at %s: %s", pub, err)
	}

	backend, _ := zmq.NewSocket(zmq.XPUB)
	defer backend.Close()

	if err := backend.Bind(sub); err != nil {
		log.Fatalf("Unable to open XPUB socket at %s: %s", sub, err)
	}

	ready <- 1

	err := zmq.Proxy(frontend, backend, nil)
	log.Fatalf("Error while proxying XSUB-XPUB: %s", err)
}

func publisher() {
	pub := os.Getenv("ATI_PUB")

	socket, _ := zmq.NewSocket(zmq.PUB)
	defer socket.Close()

	if err := socket.Connect(pub); err != nil {
		log.Fatalf("Unable to open PUB socket at %s: %s", pub, err)
	}

	for {
		command, err := readline.Line("mule> ")

		if err != nil {
			log.Fatalf("Unable to read from STDIN: %s", err)
		}

		if command == "exit" {
			return
		}

		packet, err := schema.EncodeMessage("mule.command", &schema.MuleCommand{command})

		if err != nil {
			log.Fatalf("Unable to encode message: %s", err)
		}

		socket.SendBytes(packet, 0)
	}
}
