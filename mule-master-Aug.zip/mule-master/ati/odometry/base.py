import numpy as np

class Odometry(object):
    def __init__(self, pub, sub):
        self.sub = sub

        self.velocity = np.zeros(3)
        self.welocity = np.zeros(3)
        self.rotation = np.zeros(3)
        self.position = np.zeros(3)

        self.omega_left = 0
        self.omega_right = 0

    async def run(self):
        updates = self.sub.subscribe("mule.odometry")

        while True:
            update = await updates.get()

            self.velocity[0] = update.Velocity.x
            self.velocity[1] = update.Velocity.y
            self.velocity[2] = update.Velocity.z

            self.welocity[0] = update.Welocity.x
            self.welocity[1] = update.Welocity.y
            self.welocity[2] = update.Welocity.z

            self.position[0] = update.Position.x
            self.position[1] = update.Position.y
            self.position[2] = update.Position.z

            self.rotation[0] = update.Angle.x
            self.rotation[1] = update.Angle.y
            self.rotation[2] = update.Angle.z

            self.omega_left = update.OmegaLeft
            self.omega_right = update.OmegaRight
