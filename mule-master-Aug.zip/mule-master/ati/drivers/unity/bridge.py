from __future__ import division

import ati.schema as schema
import ati.utils as utils
import threading
import socket
import struct
import random
import math

# from PIL import Image

class TCPMule(object):
    brakeInput = 0
    rightDriveInput = 1
    leftDriveInput = 2
    steerInput = 4
    resetInput = 5

    sensors = {
        0: "velocity_x",
        1: "velocity_y",
        2: "velocity_z",
        3: "position_x",
        4: "position_y",
        5: "position_z",
        6: "rotation_x",
        7: "rotation_y",
        8: "rotation_z",
        100: "fr_torque",
        101: "fl_torque",
        102: "r_torque",
        103: "fr_rpm",
        104: "fl_rpm",
        105: "r_rpm",
        110: "ultrasound_front1",
        111: "ultrasound_front2",
        112: "ultrasound_front3",
        113: "ultrasound_rear1",
        114: "ultrasound_rear2",
        115: "ultrasound_rear3",
        116: "ultrasound_left1",
        117: "ultrasound_left2",
        118: "ultrasound_right1",
        119: "ultrasound_right2",
        120: "collided",
        121: "distance",
        122: "time",
        123: "steering_angle"
    }

    sensorUncertainty = {
        "velocity_x": 0.01,
        "velocity_y": 0.01,
        "velocity_z": 0.01,
        "position_x": 0.01,
        "position_y": 0.01,
        "position_z": 0.01,
        "rotation_x": 0.01,
        "rotation_y": 0.01,
        "rotation_z": 0.01,
        "fr_torque": 0,
        "fl_torque": 0,
        "r_torque": 0,
        "fr_rpm": 0.01,
        "fl_rpm": 0.01,
        "r_rpm": 0.01,
        "ultrasound_front1": 0.05,
        "ultrasound_front2": 0.05,
        "ultrasound_front3": 0.05,
        "ultrasound_rear1": 0.05,
        "ultrasound_rear2": 0.05,
        "ultrasound_rear3": 0.05,
        "ultrasound_left1": 0.05,
        "ultrasound_left2": 0.05,
        "ultrasound_right1": 0.05,
        "ultrasound_right2": 0.05,
        "collided": 0,
        "distance": 0,
        "time": 0,
        "steering_angle": 0,
    }

    cameras = {
        200: "front",
    }

    objectTypes = {               
        0: "Background",
        1: "Blockers",
        2: "Walls",
        3: "Roads",
        4: "People",
        100: "Unknown",
    }

    roadTypes = {
        1: "straight",
        2: "deadend",
        3: "curve",
        4: "sharpCurve",
        5: "bendLeft",
        6: "bendRight",
    }

    def __init__(self):
        self.pub = utils.Bus.pub_sync()

        self.timestep = 0

        self.sensorData = {}
        self.cameraData = {}
        self.objects = {}
        self.roads = {}

        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.bind(('127.0.0.1', 6780))
        s.listen(1)

        self.conn, _ = s.accept()

        t = threading.Thread(target=self.receive_commands)
        t.daemon = True
        t.start()
    
        t = threading.Thread(target=self.cli_console)
        t.daemon = True
        t.start()

        while True:
            while self.read_sensor():
                pass

            self.push_update()

    def receive_commands(self):
        bus = utils.Bus.sub_sync(["mule.vehicle.controls"])

        while True:
            _, command = bus.recv()

            self.send(self.brakeInput, command.BrakeInput)
            self.send(self.leftDriveInput, command.LeftThrottle)
            self.send(self.rightDriveInput, command.RightThrottle)
            self.send(self.steerInput, math.degrees(command.SteeringAngle)/90.)

    def cli_console(self):
        while True:
            cmd = input("unity>")

            if cmd == "reset":
                self.reset()
            elif cmd == "manual":
                self.manual_input()
            elif cmd == "auto":
                self.conn.sendall(self.encode_bus_req(6, 0))

    def send(self, var, val):
        val *= random.uniform(0.99, 1.01)

        self.conn.sendall(self.encode_bus_req(var, val))

    def read_sensor(self):
        index = self.recv_bus_var()

        if index in self.cameras:
            width = self.recv_bus_var()
            height = self.recv_bus_var()
            val_len = self.recv_bus_var()

            image_raw = self.recvall(val_len)
            image = Image.frombytes('RGB', (width, height), val_raw, 'raw', 'RGB', 0, -1)

            self.cameraData[self.cameras[index]] = image
        # Omnipotent sensor
        elif index == 300:
            objects = self.recv_bus_var() 

            self.objects = []

            for _ in range(0, objects):
                objtype = self.recv_bus_var()
                center_x = self.recv_bus_val()
                center_y = self.recv_bus_val()
                center_z = self.recv_bus_val()
                extents_x = self.recv_bus_val()
                extents_y = self.recv_bus_val()
                extents_z = self.recv_bus_val()

                self.objects.append({
                    "type": self.objectTypes[objtype],
                    "center": [center_x, center_y, center_z],
                    "extents": [extents_x, extents_y, extents_z],
                })
        # Road sensor
        elif index == 400:
            self.roads = []

            while self.recv_bus_var() == 0:
                objtype = self.recv_bus_var()
                pos_x = self.recv_bus_val()
                pos_y = self.recv_bus_val()
                pos_z = self.recv_bus_val()
                rot_x = self.recv_bus_val()
                rot_y = self.recv_bus_val()
                rot_z = self.recv_bus_val()

                road = {
                    "type": self.roadTypes[objtype],
                    "pos": [pos_x, pos_y, pos_z],
                    "rot": [rot_x, rot_y, rot_z],
                }

                if road not in self.roads:
                    self.roads.append(road)
        elif index == 1000:
            self.recv_bus_val()
            return False
        else:
            name = self.sensors[index]

            uncertainty = self.sensorUncertainty[name] / 100

            self.sensorData[name] = self.recv_bus_val()

            if uncertainty:
                self.sensorData[name] *= random.uniform(1 - uncertainty, 1 + uncertainty)

        return True

    def push_update(self):
        odometry_update = schema.OdometryUpdate()

        odometry_update.Position.x = self.sensorData['position_x']
        odometry_update.Position.y = self.sensorData['position_z']
        odometry_update.Position.z = self.sensorData['position_y']

        odometry_update.Angle.x = math.radians(90 - self.sensorData['rotation_x'])
        odometry_update.Angle.y = math.radians(90 - self.sensorData['rotation_z'])
        odometry_update.Angle.z = math.radians(90 - self.sensorData['rotation_y'])

        odometry_update.Velocity.x = self.sensorData['velocity_x']
        odometry_update.Velocity.y = self.sensorData['velocity_z']
        odometry_update.Velocity.z = self.sensorData['velocity_y']

        odometry_update.OmegaRight = .104719755 * self.sensorData['fr_rpm'] # RPM to rad/s
        odometry_update.OmegaLeft = .104719755 * self.sensorData['fl_rpm'] # RPM to rad/s

        self.pub.send("mule.odometry", odometry_update)

        self.timestep += 1
        self.pub.send("mule.vehicle.timestep", schema.Timestep(Timestep=self.timestep))

    def recvall(self, bufsize):
        buf = b""

        while len(buf) < bufsize:
            new_buf = self.conn.recv(bufsize - len(buf))
            if not new_buf: return None
            buf += new_buf

        return buf

    def encode_bus_req(self, var, val):
        return struct.pack('@Qd', var, val)

    def decode_bus_var(self, var):
        return struct.unpack("@Q", var)[0]

    def decode_bus_val(self, val):
        return struct.unpack("@d", val)[0]

    def recv_bus_var(self):
        return self.decode_bus_var(self.recvall(8))

    def recv_bus_val(self):
        return self.decode_bus_val(self.recvall(8))

    def reset(self):
        self.conn.sendall(self.encode_bus_req(self.resetInput, 1))

    def manual_input(self):
        self.conn.sendall(self.encode_bus_req(6, 1))

    def add_marker(self, x, y):
        self.conn.sendall(self.encode_bus_req(7, x))
        self.conn.sendall(self.encode_bus_req(8, y))
