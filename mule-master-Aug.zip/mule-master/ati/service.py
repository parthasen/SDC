import ati.utils as utils
import asyncio
import re

class Service(object):
    """
    A base class for a service.

    You can define a class attribute dependencies with a list of dependencies to
    instantiate.
    """

    dependencies = []

    def __init__(self):
        super().__init__()

        self.pub = utils.Bus.pub()
        self.sub = utils.Bus.sub()

        dependencies_run = []

        for dependency in self.dependencies:
            instance = dependency(self.pub, self.sub)

            name = self.camel_to_snake(type(instance).__name__)

            setattr(self, name, instance)

            dependencies_run.append(instance.run())

        asyncio.get_event_loop().run_until_complete(asyncio.gather(self.sub.run(),
            self.run(), *dependencies_run))

    def camel_to_snake(self, name):
        s1 = re.sub('(.)([A-Z][a-z]+)', r'\1_\2', name)
        return re.sub('([a-z0-9])([A-Z])', r'\1_\2', s1).lower()

    async def run(self):
        raise NotImplementedError("Service is a base class")
