from __future__ import division

import math
import sys
import os

sys.path.append(os.path.abspath('.'))

from mule.low_control import MuleController
from mule.bridge import TCPMule

if __name__ == '__main__':
    controller = MuleController()

    controller.desired_velocity = 3.

    mule = TCPMule(controller.update)

    for timestep, _ in enumerate(mule.run()):
        controller.update(mule)

        if timestep == 200:
            controller.desired_velocity = 10.

        if timestep == 400:
            controller.desired_omega = 10.

        if timestep == 600:
            controller.desired_omega = 0.
