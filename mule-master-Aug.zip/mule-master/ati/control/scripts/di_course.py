from __future__ import division

import math
import sys
import os

sys.path.append(os.path.abspath('.'))

from mule.low_control import MuleController
from mule.bridge import TCPMule
from mule.utils import PID

# x_star_dot = [0 for _ in range(0, 20 * 120)]
# y_star_dot = [10 for _ in range(0, 20 * 120)]

# x_star = [-450 for _ in range(0, 20 * 120)]
# y_star = [-497 + i / 2. for i in range(0, 20 * 120)]

x_star_dot = 0
y_star_dot = 0
x_star = -450
y_star = -475

k_x = 0.5
k_y = 0.5

phi_controller = PID(2, 0.5, 0)

if __name__ == '__main__':
    mule = TCPMule(None)
    controller = MuleController()

    for timestep, _ in enumerate(mule.run()):
        curr_x = mule.sensorData['position_x']
        curr_y = mule.sensorData['position_z']
        e_x = x_star - curr_x
        e_y = y_star - curr_y
        v_cosphi = x_star_dot - k_x * e_x
        v_sinphi = y_star_dot - k_y * e_y

        phi = math.degrees(math.atan2(v_sinphi, v_cosphi))
        vel = math.sqrt(v_cosphi**2 + v_sinphi**2)

        print e_x, e_y, curr_x, curr_y, phi, vel

        # Get heading error
        phi_e = math.radians(phi - mule.sensorData['rot_y'])

        phi_e = math.atan2(math.sin(phi_e), math.cos(phi_e))

        if controller.desired_velocity == 0:
            max_omega = 4
        else:
            max_omega = 8/controller.desired_velocity # a_y / v gives you max omega

        controller.desired_omega = math.degrees(min(
            phi_controller.update(phi_e), 
            max_omega
        ))

        controller.desired_velocity = vel

        controller.update(mule)

        if abs(e_x) < 0.5 and abs(e_y) < 0.5:
            mule.send_bus_req(mule.rightDriveInput, 0)
            mule.send_bus_req( mule.leftDriveInput, 0)
            mule.send_bus_req(mule.brakeInput, 1)
            mule.send_bus_req(mule.steerInput, 0)
            break

        print "Done!!"
