import math
import sys
import os

sys.path.append(os.path.abspath('.'))

import ati.schema as schema

from ati.control.low_control import WheelController
from ati.odometry import Odometry
from ati.service import Service
from ati.control.pid import PID


waypoints = [
    (24, 30),
    (28, 40),
    (32, 48),
    (32, 70),
    (28, 78),
    (24, 78),
    (20, 72),
    (20, 56),
    (20, 52),
    (24, 50),
    (40, 50),
    (48, 44),
    (56, 40),
    (64, 41),
    (72, 52),
    (72, 60),
    (68, 62),
    (64, 64),
    (60, 66),
    (56, 70),
    (52, 72),
    (48, 72),
    (44, 76),
    (44, 80),
    (44, 84),
    (48, 88),
    (56, 86),
    (60, 82),
    (68, 80),
    (76, 78),
    (80, 74),
    (84, 66),
    (84, 60),
    (88, 58),
    (92, 52),
    (92, 44),
    (88, 38),
    (84, 34),
    (80, 32),
    (76, 30),
    (72, 30),
    (68, 28),
    (64, 24),
    (56, 22),
    (48, 22),
    (44, 20),
    (44, 16),
    (48, 10),
    (64, 10),
]

class SimpleCourse(Service):
    dependencies = [Odometry]

    async def run(self):
        waypoint = 0

        controller = WheelController()

        controller.desired_velocity = 6.

        phi_controller = PID(1.75, 0, 0)

        timesteps = self.sub.subscribe("mule.vehicle.timestep")

        while True:
            timestep = await timesteps.get()

            x_diff = waypoints[waypoint][0] - self.odometry.position[0]
            y_diff = waypoints[waypoint][1] - self.odometry.position[1]

            magnitude = math.sqrt(x_diff ** 2 + y_diff ** 2)

            # Get heading error
            phi_e = self.odometry.rotation[2] - math.atan2(y_diff, x_diff)

            phi_e = math.atan2(math.sin(phi_e), math.cos(phi_e))

            controller.desired_omega = min(
                phi_controller.update(phi_e), 
                8/controller.desired_velocity # a_y / v gives you max omega
            )

            if magnitude < 4:
                waypoint += 1

                if waypoint == len(waypoints):
                    self.pub.send("mule.vehicle.controls", schema.VehicleControls(BrakeInput=1))

                    print("ARRIVED!")

                    return

                # mule.add_marker(waypoints[waypoint][0], waypoints[waypoint][1])
                print(waypoints[waypoint])

            await self.pub.send("mule.vehicle.controls", controller.update(self.odometry))

if __name__ == '__main__':
    SimpleCourse()
