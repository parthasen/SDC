from __future__ import division

import math


class PathSegment(object):
    def __init__(self, omega, v, t):
        self.omega = omega
        self.v = v
        self.t = t


class PathController(object):
    wdot_max = 1
    vdot_max = 3

    def __init__(self):
        self._segments = []
        self._segments_dirty = False

    def add_segment(self, segment):
        self._segments.append(segment)

    def delete_segment(self, segment):
        if segment == 0:
            self._segments_dirty = True

        self._segments.pop(segment)

    def update(self, controller):
        if not self._segments_dirty:
            self._segments[0].t -= 0.05

        if self._segments[0].t <= 0:
            self._segments.pop(0)

        if len(self._segments) <= 1:
            controller.brake_input = 0.1
            controller.desired_velocity = 0
            controller.desired_omega = 0

            return

        dw = self._segments[1].omega - self._segments[0].omega
        dv = self._segments[1].v - self._segments[0].v

        transition_time = max(dw/self.wdot_max, dv/self.vdot_max)

        if self._segments[0].t < transition_time:
            alpha = self._segments[0].t / transition_time

            omega = self._segments[0].omega * (1 - alpha) + self._segments[1].omega * alpha
            v     = self._segments[0].v * (1 - alpha) + self._segments[1].v * alpha
        else:
            omega = self._segments[0].omega
            v     = self._segments[0].v

        controller.desired_velocity = v
        controller.desired_omega = math.degrees(omega)
        controller.brake_input = 0
