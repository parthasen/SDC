from .messages_pb2 import MuleCommand, MuleStatus, OdometryUpdate, VehicleControls
from .messages_pb2 import Timestep, Vector

class InvalidTopic(Exception):
    pass

class InvalidMessage(Exception):
    pass

def encode_message(topic, message):
    return bytes(topic, 'utf-8') + b'\000' + message.SerializeToString()

def decode_message(packet):
    if b'\000' not in packet:
        raise InvalidMessage()

    topic, raw_message = packet.split(b'\000', maxsplit=1)

    topic = topic.decode('utf-8')

    if topic == "mule.odometry":
        message = OdometryUpdate()
    elif topic == "mule.vehicle.controls":
        message = VehicleControls()
    elif topic == "mule.vehicle.timestep":
        message = Timestep()
    elif topic == "mule.command":
        message = MuleCommand()
    elif topic == "mule.status":
        message = MuleStatus()
    else:
        raise InvalidTopic()

    message.ParseFromString(raw_message)

    return topic, message