package schema

import (
	"bytes"
	"errors"
	"github.com/golang/protobuf/proto"
)

func DecodeMessage(packet []byte) (topic string, message proto.Message, err error) {
	buf := bytes.NewBuffer(packet)

	topic_bytes, err := buf.ReadBytes('\000')

	if err != nil {
		return
	}

	topic = string(topic_bytes[:len(topic_bytes)-1])

	raw_packet := buf.Bytes()

	message, err = unmarshalMessage(topic, raw_packet)

	return
}

func unmarshalMessage(topic string, raw_packet []byte) (proto.Message, error) {
	var message proto.Message

	switch topic {
	case "mule.odometry":
		message = &OdometryUpdate{}
	case "mule.vehicle.controls":
		message = &VehicleControls{}
	case "mule.vehicle.timestep":
		message = &Timestep{}
	case "mule.command":
		message = &MuleCommand{}
	case "mule.status":
		message = &MuleStatus{}
	default:
		return nil, errors.New("schema.UnmarshalMessage(): Invalid/Unsupported topic")
	}

	if err := proto.Unmarshal(raw_packet, message); err != nil {
		return nil, err
	}

	return message, nil
}

func EncodeMessage(topic string, message proto.Message) (packet []byte, err error) {
	encoded_message, err := proto.Marshal(message)

	if err != nil {
		return
	}

	null_topic := append([]byte(topic), '\000')

	packet = append(null_topic, encoded_message...)

	return
}
