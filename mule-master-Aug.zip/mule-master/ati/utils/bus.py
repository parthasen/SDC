import ati.schema as schema
import zmq.asyncio
import asyncio
import zmq
import os

context = zmq.asyncio.Context()
sync_context = zmq.Context()

zmq.asyncio.install()

class Bus(object):
    def __init__(self, socket):
        self.socket = socket
        self.recv_queues = {}

    @classmethod
    def sub(cls):
        socket = context.socket(zmq.SUB)
        socket.connect(os.getenv("ATI_SUB"))

        return cls(socket)

    @classmethod
    def sub_sync(cls, topics):
        socket = sync_context.socket(zmq.SUB)
        socket.connect(os.getenv("ATI_SUB"))

        for topic in topics:
            socket.setsockopt_string(zmq.SUBSCRIBE, topic)

        return cls(socket)

    @classmethod
    def pub_sync(cls):
        socket = sync_context.socket(zmq.PUB)
        socket.connect(os.getenv("ATI_PUB"))

        return cls(socket)

    @classmethod
    def pub(cls):
        socket = context.socket(zmq.PUB)
        socket.connect(os.getenv("ATI_PUB"))

        return cls(socket)

    def subscribe(self, topic):
        q = asyncio.Queue()

        if topic in self.recv_queues:
            self.recv_queues[topic].append(q)
        else:
            self.recv_queues[topic] = [q]

        self.socket.setsockopt_string(zmq.SUBSCRIBE, topic)

        return q

    def send(self, topic, message):
        return self.socket.send(schema.encode_message(topic, message))

    def recv(self):
        return schema.decode_message(self.socket.recv())

    async def run(self):
        while True:
            packet = await self.socket.recv()
            topic, message = schema.decode_message(packet)

            if topic in self.recv_queues:
                for q in self.recv_queues[topic]:
                    q.put_nowait(message)

    def close(self):
        self.socket.close()
