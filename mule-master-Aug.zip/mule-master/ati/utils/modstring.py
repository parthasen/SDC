import importlib

def get_class(path):
    try:
        module, attribute = path.rsplit('.', 1)
    except ValueError:
        raise ImportError("{} is not a valid path".format(path))

    module = importlib.import_module(module)

    try:
        return getattr(module, attribute)
    except AttributeError:
        raise ImportError("Module {} does not contain {}".format(module, attribute))
