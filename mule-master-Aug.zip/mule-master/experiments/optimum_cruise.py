from turning_radius import MuleController
from unity_server import Mule
from pid import PID

import math
import numpy as np

class OptimumCruiseController(object):
    def __init__(self):
        self.timestep = 0
        self.controller = MuleController()
        self.controller.desired_velocity = 0
    
    def update(self, mule):
        self.controller.update(mule)

        if self.timestep == 0:
            self.timestep += 1
            return

        if self.timestep % 100 == 0:
            self.controller.desired_velocity += 1

            print "{} m/s: {} W, {} W, {} W".format(
                mule.sensorData['velocity_z'],
                0.105 * mule.sensorData['fr_rpm'] * mule.sensorData['fr_torque'],
                0.105 * mule.sensorData['fl_rpm'] * mule.sensorData['fl_torque'],
                0.105 * mule.sensorData['r_rpm'] * mule.sensorData['r_torque'],
            )

        self.timestep += 1

if __name__ == '__main__':
    controller = OptimumCruiseController()
    mule = Mule(controller.update)
    mule.run()
