from __future__ import division
import math

wheel_radius = 0.3
mass = 200

rho = 1.225
area = 0.6 # 1m width 0.6m height
c_d = 0.4

max_speed = 45/3.6 # 45 km/hr

desired_grade = math.radians(15) # 15 degrees
desired_grade_speed = 8/3.6     # 8 km/hr
desired_grade_acceleration = 1  # 1 m/s^2

desired_straight_speed = 28.8/3.6    # 45 km/hr
desired_straight_acceleration = 1  # 1 m/s^2

desired_peak_speed = 45/3.6   # 45 km/hr
desired_peak_acceleration = 3 # 3 m/s^2

def drag_force(velocity):
    return 0.5 * rho * velocity**2 * area * c_d

def rolling_resistance():
    return 0.025 * mass * 9.81

def bad_rolling_resistance():
    return 0.15 * mass * 9.81

def grade_resistance(grade):
    return mass * 9.81 * math.sin(desired_grade)

def speed_to_rpm(speed):
    return (60 * speed)/(2 * math.pi * wheel_radius)

max_rpm = speed_to_rpm(max_speed)

print "Max RPM must be at least {}".format(max_rpm)

print "ON GRADE: {:.2f} m/s^2 at {:.2f} km/hr".format(
    desired_grade_acceleration, 
    desired_grade_speed * 3.6)

desired_grade_rpm = speed_to_rpm(desired_grade_speed)

desired_grade_force = drag_force(desired_grade_speed)
desired_grade_force += rolling_resistance()
desired_grade_force += grade_resistance(desired_grade)
desired_grade_force += mass * desired_grade_acceleration

print "\t{:.2f} N drag".format(drag_force(desired_grade_speed)) 
print "\t{:.2f} N rolling resistance".format(rolling_resistance()) 
print "\t{:.2f} N grade resistance".format(grade_resistance(desired_grade)) 
print "\t{:.2f} N acceleration".format(mass * desired_grade_acceleration)
print "\t{:.2f} N total".format(desired_grade_force) 

desired_grade_torque = desired_grade_force * wheel_radius

print "\tNeed {:.2f} N-m of torque at {:.2f} RPM - {:.2f} kW".format(
    desired_grade_torque, desired_grade_rpm, desired_grade_force * desired_grade_speed / 1000.)

print "ON STRAIGHT ROAD: {:.2f} km/hr".format(desired_straight_speed * 3.6)

desired_straight_rpm = speed_to_rpm(desired_straight_speed)

desired_straight_force = drag_force(desired_straight_speed)
desired_straight_force += rolling_resistance()

print "\t{:.2f} N drag".format(drag_force(desired_straight_speed))
print "\t{:.2f} N rolling resistance".format(rolling_resistance())
print "\t{:.2f} N total".format(desired_straight_force)

desired_straight_torque = desired_straight_force * wheel_radius

print "\tNeed {:.2f} N-m of torque at {:.2f} RPM - {:.2f} kW".format(
    desired_straight_torque, desired_straight_rpm, desired_straight_force * desired_straight_speed / 1000.)

print "PEAK POWER: {:.2f} m/s^2 at {:.2f} km/hr".format(
    desired_peak_acceleration, 
    desired_peak_speed * 3.6)

desired_peak_rpm = speed_to_rpm(desired_peak_speed)

desired_peak_force = drag_force(desired_peak_speed)
desired_peak_force += rolling_resistance()
desired_peak_force += mass * desired_peak_acceleration

print "\t{:.2f} N drag".format(drag_force(desired_peak_speed))
print "\t{:.2f} N rolling resistance".format(rolling_resistance())
print "\t{:.2f} N acceleration".format(mass * desired_peak_acceleration)
print "\t{:.2f} N total".format(desired_peak_force)

desired_peak_torque = desired_peak_force * wheel_radius

print "\tNeed {:.2f} N-m of torque at {:.2f} RPM - {:.2f} kW".format(
    desired_peak_torque, desired_peak_rpm, desired_peak_force * desired_peak_speed / 1000.)

print "ON MUDDY GRADE: {:.2f} m/s^2 at {:.2f} km/hr".format(
    desired_grade_acceleration, 
    desired_grade_speed * 3.6)

desired_grade_rpm = speed_to_rpm(desired_grade_speed)

desired_grade_force = drag_force(desired_grade_speed)
desired_grade_force += bad_rolling_resistance()
desired_grade_force += grade_resistance(desired_grade)
desired_grade_force += mass * desired_grade_acceleration

print "\t{:.2f} N drag".format(drag_force(desired_grade_speed)) 
print "\t{:.2f} N rolling resistance".format(rolling_resistance()) 
print "\t{:.2f} N grade resistance".format(grade_resistance(desired_grade)) 
print "\t{:.2f} N acceleration".format(mass * desired_grade_acceleration)
print "\t{:.2f} N total".format(desired_grade_force) 

desired_grade_torque = desired_grade_force * wheel_radius

print "\tNeed {:.2f} N-m of torque at {:.2f} RPM - {:.2f} kW".format(
    desired_grade_torque, desired_grade_rpm, desired_grade_force * desired_grade_speed / 1000.)
