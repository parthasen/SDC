export ATI_SUB=ipc:///$(pwd)/out/zmq_sub
export ATI_PUB=ipc:///$(pwd)/out/zmq_pub