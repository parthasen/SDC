from unity_server import Mule
from pid import PID

import math
import numpy as np

class MuleController(object):
    def __init__(self):
        self.velocity_pid = PID(1, .01, 0)
        self.heading_pid = PID(1, 0, 5)
        self.yawrate_pid = PID(0.5, 0, 0.1)

        self.desired_yawrate = 0
        self.previous_heading = 0

        self.desired_velocity = 0
        self.desired_heading = 0

        self.throttle_scale = 1
        self.steering_scale = 1

    def update(self, mule):
        velocity = mule.sensorData['velocity_z']
        heading = math.radians(mule.sensorData['rot_y'])

        yawrate = (heading - self.previous_heading) * 0.1

        velocity_e = self.desired_velocity - velocity
        yawrate_e = self.desired_yawrate - yawrate

        # heading_e = math.radians(self.desired_heading) - math.radians(mule.sensorData['rot_y'])
        # heading_e = math.atan2(math.sin(heading_e), math.cos(heading_e))

        throttle = np.clip(self.velocity_pid.update(velocity_e), -1, 1)
        steering = np.clip(self.heading_pid.update(yawrate_e), -1, 1)
        # steering = np.clip(self.heading_pid.update(heading_e), -1, 1)

        if (-0.01 > self.desired_velocity > 0.01):
            throttle = 0
            brake = 1
        else:
            brake = 0

        # print "throttle: {}, brake: {}, steering: {}, velocity_e: {}, heading_e: {}".format(
        #     throttle, brake, steering, velocity_e, heading_e
        # )

        mule.send_bus_req(mule.rightDriveInput, throttle * self.throttle_scale)
        mule.send_bus_req(mule.leftDriveInput, throttle * self.throttle_scale)
        mule.send_bus_req(mule.rearDriveInput, throttle * self.throttle_scale)
        mule.send_bus_req(mule.brakeInput, brake * self.throttle_scale)

        mule.send_bus_req(mule.steerInput, -steering * self.steering_scale)


class TurningRadiusController(object):
    def __init__(self):
        self.timestep = 0
        self.controller = MuleController()
        self.controller.desired_velocity = 3
    
    def update(self, mule):
        self.controller.update(mule)

        if 'position_x' in mule.sensorData:
            print "{}, {}, {}, {}, {}".format(
                mule.sensorData['position_x'],
                mule.sensorData['position_y'],
                mule.sensorData['position_z'],
                mule.sensorData['rot_y'],
                (mule.sensorData['rot_y'] - self.controller.previous_heading) * 0.1,
            )

        if self.timestep == 100:
            self.controller.desired_yawrate = 90

        self.timestep += 1


if __name__ == '__main__':
    print "x,y,z,rot,yawrate"

    controller = TurningRadiusController()
    mule = Mule(controller.update)
    mule.run()
