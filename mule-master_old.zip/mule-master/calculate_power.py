import csv

from epacycle import EPACycle

dt = 0.1
regen_efficiency = 0.2
drive_efficiency = 1.2

# Vehicle fixed power consumption (in watts)
fixed_power = 100

def calc_energy(power):
    # Regenerative braking efficiency is low
    if power < 0:
        return power * regen_efficiency * dt + fixed_power * dt
    else:
        return power * drive_efficiency * dt + fixed_power * dt

speeds = []

with open('epa_urban_power.csv', 'rb') as f:
    reader = csv.reader(f)
    power_data = list(reader)

energy = 0
distance = 0

for power_stat in power_data:
    energy += calc_energy(float(power_stat[0])) / 3600.
    energy += calc_energy(float(power_stat[1])) / 3600.
    energy += calc_energy(float(power_stat[2])) / 3600.
    distance += float(power_stat[3]) * dt

print "Distance: {} m, Energy: {} Wh".format(distance, energy)

km_energy = energy / (distance / 1000)

print "Distance: 1 km, Energy: {} Wh".format(km_energy)
print "{} km of EPA range".format(6000/km_energy)
