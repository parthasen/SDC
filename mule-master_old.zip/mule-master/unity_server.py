import socket
import struct
import cStringIO

from pid import PID
from epacycle import EPACycle
from PIL import Image

class Mule(object):
    brakeInput = 0
    rightDriveInput = 1
    leftDriveInput = 2
    rearDriveInput = 3
    steerInput = 4

    sensors = {
        0L: "velocity_x",
        1L: "velocity_y",
        2L: "velocity_z",
        3L: "position_x",
        4L: "position_y",
        5L: "position_z",
        6L: "rot_x",
        7L: "rot_y",
        8L: "rot_z",
        100L: "fr_torque",
        101L: "fl_torque",
        102L: "r_torque",
        103L: "fr_rpm",
        104L: "fl_rpm",
        105L: "r_rpm",
    }

    cameras = {
        200L: "front",
    }

    def __init__(self, callback):
        self.sensorData = {}
        self.cameraData = {}
        self.callback = callback

    def run(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.bind(('127.0.0.1', 6780))
        s.listen(1)

        self.conn, _ = s.accept()

        while 1:
            data = self.recv_bus_reqs()
            if not data: break

            self.update_sensors(data)

            self.callback(self)

        self.conn.close()

    def update_sensors(self, reqs):
        for req in reqs:
            if req[0] in self.sensors:
                self.sensorData[self.sensors[req[0]]] = req[1]

            if req[0] in self.cameras:
                self.cameraData[self.cameras[req[0]]] = req[1]

    def send_bus_req(self, var, val):
        self.conn.sendall(self.encode_bus_req(var, val))

    def recv_bus_reqs(self):
        reqs = []

        while True:
            req = self.recv_bus_req()

            if not req:
                return None

            if req[0] == 1000:
                return reqs

            reqs.append(req)

    def recv_bus_req(self):
        raw_var = self.recvall(8)

        var = self.decode_bus_var(raw_var)

        if var in self.cameras:
            width = self.decode_bus_var(self.recvall(8))
            height = self.decode_bus_var(self.recvall(8))
            val_len = self.decode_bus_var(self.recvall(8))

            val_raw = self.recvall(val_len)
            val = Image.frombytes('RGB', (width, height), val_raw, 'raw', 'RGB', 0, -1)
        else:
            val = self.recvall(8)
            val = self.decode_bus_val(val)

        return (var, val)

    def recvall(self, bufsize):
        buf = ""

        while len(buf) < bufsize:
            new_buf = self.conn.recv(bufsize - len(buf))
            if not new_buf: return None
            buf += new_buf

        return buf

    def encode_bus_req(self, var, val):
        return struct.pack('@Qd', var, val)

    def decode_bus_var(self, var):
        return struct.unpack("@Q", var)[0]

    def decode_bus_val(self, val):
        return struct.unpack("@d", val)[0]


def testCallbackCreator(pid, cycle):
    timestep = [0]

    def testCallback(mule):
        target = cycle.timestep(timestep[0])

        if 'velocity_z' in mule.sensorData:
            e = target - mule.sensorData['velocity_z']
        else:
            e = 0

        out = pid.update(e)

        # if 'front' in mule.cameraData:
        #     if timestep[0] == 100:
        #         mule.cameraData['front'].save("front.png","PNG")
        #         os.exit(1)

        # print "target {}, error {}, output {}".format(target, e, out)
        if 'fr_rpm' in mule.sensorData:
            print "{}, {}, {}, {}".format(
                0.105 * mule.sensorData['fr_rpm'] * mule.sensorData['fr_torque'],
                0.105 * mule.sensorData['fl_rpm'] * mule.sensorData['fl_torque'],
                0.105 * mule.sensorData['r_rpm'] * mule.sensorData['r_torque'],
                mule.sensorData['velocity_z'],
            )

        mule.send_bus_req(mule.rightDriveInput, out)
        mule.send_bus_req(mule.leftDriveInput, out)
        mule.send_bus_req(mule.rearDriveInput, out)

        timestep[0] += 1

    return testCallback

if __name__ == '__main__':
    cycle = EPACycle("epa_urban")
    pid = PID(0.8, 0, 0)
    mule = Mule(testCallbackCreator(pid, cycle))
    mule.run()
