# Motor
Max RPM must be at least 552.62133018

450.493333333 N at 147.365688048 RPM for accelerating at 1 m/s^2 at 12.0 km/hr on a 30.0% grade

Need 145.95984 N-m max torque, 552.62133018 max RPM from motors

Max power is 2.1116875 kW per motor

To get power from RPM and Nm, calculate
```
power = .105 * RPM * torque
```

Our battery is `9600` Watt hours (61.44 kg)

On 45 kgs of battery, we can get 250 km EPA range.

# EPA urban cycle
Distance: 7118 m, Energy: 258 Wh
Distance: 1 km, Energy: 36 Wh (extrapolated)

165 km EPA range

# Turning radius

Raw output:
```
-450.0, 0.0376823283732, -464.912109375
-443.735168457, 0.0376811027527, -486.637542725

-450.0, 0.0376809574664, -463.988952637
-453.502319336, 0.0376824736595, -489.775482178
```
