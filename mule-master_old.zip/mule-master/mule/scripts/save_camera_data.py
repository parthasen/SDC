from __future__ import division

import math
import sys
import os

sys.path.append(os.path.abspath('.'))

from mule.low_control import MuleController
from mule.bridge import TCPMule

if __name__ == '__main__':
    mule = TCPMule(None)

    for timestep, _ in enumerate(mule.run()):
        if timestep == 1:
            mule.manual_input()

        frame = mule.cameraData['front']

        front = frame.crop((
            frame.width - 320,
            0,
            frame.width,
            240
        ))

        front.save('camera_data/center/{}.jpg'.format(timestep))

        print "{}.jpg, {}".format(timestep, mule.sensorData['steering_angle'])
