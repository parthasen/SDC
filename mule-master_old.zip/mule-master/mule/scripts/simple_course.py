from __future__ import division

import math
import sys
import os

sys.path.append(os.path.abspath('.'))

from mule.low_control import MuleController
from mule.bridge import TCPMule
from mule.utils import PID

waypoints = [
    (24, 30),
    (28, 40),
    (32, 48),
    (32, 70),
    (28, 78),
    (24, 78),
    (20, 72),
    (20, 56),
    (20, 52),
    (24, 50),
    (40, 50),
    (48, 44),
    (56, 40),
    (64, 41),
    (72, 52),
    (72, 60),
    (68, 62),
    (64, 64),
    (60, 66),
    (56, 70),
    (52, 72),
    (48, 72),
    (44, 76),
    (44, 80),
    (44, 84),
    (48, 88),
    (56, 86),
    (60, 82),
    (68, 80),
    (76, 78),
    (80, 74),
    (84, 66),
    (84, 60),
    (88, 58),
    (92, 52),
    (92, 44),
    (88, 38),
    (84, 34),
    (80, 32),
    (76, 30),
    (72, 30),
    (68, 28),
    (64, 24),
    (56, 22),
    (48, 22),
    (44, 20),
    (44, 16),
    (48, 10),
    (64, 10),
]

if __name__ == '__main__':
    waypoint = 0

    controller = MuleController()

    controller.desired_velocity = 6.

    mule = TCPMule(controller.update)

    phi_controller = PID(2, 0, 0)

    for timestep, _ in enumerate(mule.run()):
        x_diff = waypoints[waypoint][0] - mule.sensorData['position_x']
        y_diff = waypoints[waypoint][1] - mule.sensorData['position_z']

        magnitude = math.sqrt(x_diff ** 2 + y_diff ** 2)

        controller.desired_phi = math.degrees(math.atan2(x_diff, y_diff))

        desired_phi = math.degrees(math.atan2(x_diff, y_diff))

        # Get heading error
        phi_e = math.radians(desired_phi - mule.sensorData['rot_y'])

        phi_e = math.atan2(math.sin(phi_e), math.cos(phi_e))

        controller.desired_omega = math.degrees(min(
            phi_controller.update(phi_e), 
            8/controller.desired_velocity # a_y / v gives you max omega
        ))

        if magnitude < 4:
            waypoint += 1

            if waypoint == len(waypoints):
                mule.send_bus_req(mule.rightDriveInput, 0)
                mule.send_bus_req( mule.leftDriveInput, 0)

                mule.send_bus_req(mule.brakeInput, 1)

                mule.send_bus_req(mule.steerInput, 0)

                print "ARRIVED!"

                break

            mule.add_marker(waypoints[waypoint][0], waypoints[waypoint][1])
            print waypoints[waypoint]

        controller.update(mule)
