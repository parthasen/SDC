from __future__ import division

import math
import sys
import os

sys.path.append(os.path.abspath('.'))

from mule.bridge import TCPMule

if __name__ == '__main__':
    mule = TCPMule(None)

    print "x, y"

    for timestep, _ in enumerate(mule.run()):
        mule.manual_input()

        print "{}, {}".format(mule.sensorData['position_x'], mule.sensorData['position_z'])
