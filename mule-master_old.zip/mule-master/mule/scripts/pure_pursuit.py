from __future__ import division

import pandas as pd
import math
import sys
import os

sys.path.append(os.path.abspath('.'))

from mule.low_control import MuleController
from mule.bridge import TCPMule
from mule.utils import PID

# Vector operations

class Point(object):
    def __init__(self, x, y):
        self.x = x
        self.y = y

def distance(a, b):
    dist2 = (a.x - b.x) ** 2 + (a.y - b.y) **2

    return math.sqrt(dist2)

def subtract(a, b):
    return Point(a.x - b.x, a.y - b.y)

def rotate(v, theta):
    return Point(v.x * math.cos(theta) - v.y * math.sin(theta), v.x * math.sin(theta) + v.y * math.cos(theta))

# Pure pursuit code

def pure_pursuit(vehicle_position, vehicle_rotation, anchor):
    anchor = subtract(anchor, vehicle_position)
    anchor = rotate  (anchor, vehicle_rotation)

    r = (anchor.x**2 + anchor.y**2)/(2 * anchor.x)

    v = min(10, math.sqrt(4 * math.fabs(r)))

    return v, r

raw_waypoints = pd.read_csv('eda/city_course.csv')

waypoints = []

for x in range(0, len(raw_waypoints)):
    waypoints.append(Point(raw_waypoints.x[x], raw_waypoints.y[x]))

cumulative_error = 0

if __name__ == '__main__':
    closest_waypoint = 0

    mule = TCPMule(None)
    controller = MuleController()

    for timestep, _ in enumerate(mule.run()):
        vehicle_position = Point(mule.sensorData['position_x'], mule.sensorData['position_z'])
        vehicle_rotation = math.radians(mule.sensorData['rot_y'])

        # Update closest waypoint
        distance_min = distance(vehicle_position, waypoints[closest_waypoint])

        for i in range(closest_waypoint + 1, len(waypoints)):
            new_dist = distance(vehicle_position, waypoints[i])

            if new_dist < distance_min:
                closest_waypoint = i

                distance_min = new_dist
            else:
                break

        cumulative_error += distance(vehicle_position, waypoints[closest_waypoint])

        # Get anchors

        rotation_anchor = None
        velocity_anchor = None

        lookahead = mule.sensorData['velocity_z']
        # lookahead = 5

        for i in range(closest_waypoint + 1, len(waypoints)):
            if distance(vehicle_position, waypoints[i]) > lookahead:
                rotation_anchor = waypoints[i]
                break

        for i in range(closest_waypoint + 1, len(waypoints)):
            if distance(vehicle_position, waypoints[i]) > lookahead * 2:
                velocity_anchor = waypoints[i]
                break

        if (rotation_anchor is None) or (velocity_anchor is None):
            mule.send_bus_req(mule.rightDriveInput, 0)
            mule.send_bus_req( mule.leftDriveInput, 0)

            mule.send_bus_req(mule.brakeInput, 1)

            mule.send_bus_req(mule.steerInput, 0)

            print "ARRIVED! {} m".format(cumulative_error)

            break

        # mule.add_marker(rotation_anchor.x, rotation_anchor.y)

        _, r = pure_pursuit(vehicle_position, vehicle_rotation, rotation_anchor)
        v, _ = pure_pursuit(vehicle_position, vehicle_rotation, velocity_anchor)

        controller.desired_velocity = v
        controller.desired_omega = math.degrees(v/r)

        controller.update(mule)
