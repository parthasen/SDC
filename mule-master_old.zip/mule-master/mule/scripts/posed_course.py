from __future__ import division

import math
import sys
import os

sys.path.append(os.path.abspath('.'))

from mule.low_control import MuleController
from mule.bridge import TCPMule
from mule.utils import PID

waypoints = [
    (40, 40, 45),
    (80, 80, 60),
    (100, 100, 0),
]

waypoints = [
    (-16.5, -78.15, 93),
    (8.35, -74, 93),
    (95, -78, 93),
    (110, -73.5, 93),
    (110, -73.5, 93),
    (117, -70.0, 0),
    (109, -63.0, 273),
    ( 67, -60.8, 273),
]

waypoint = 0

v_t = 3 # Transition velocity in m/s

omega_old = 0

transitioning = 0
tranisition_time = 30 # 1.5 seconds

k1 = 1
k2 = 5

def sigma_t(t, tau):
    return (1 / 0.98) * (1 / (1 + math.exp(-9.2 * (t / tau - 0.5))) - 0.01)

def control_law(x, y, gamma, target_x, target_y, target_gamma, vel=None):
    gamma = math.atan2(math.sin(gamma), math.cos(gamma))
    target_gamma = math.atan2(math.sin(target_gamma), math.cos(target_gamma))

    e_x = target_x - x
    e_y = target_y - y

    r = math.sqrt(e_y ** 2 + e_x ** 2)

    alpha = math.atan2(e_y, e_x)

    delta = alpha - gamma
    theta = alpha - target_gamma

    delta_desired = math.atan(-k1 * theta)

    kappa = - (1 / r) * (
        k2 * (delta - delta_desired) + 
        math.sin(delta) * (1 + k1 / (1 + (k1 * theta)**2))
    )

    v = 10 / (1 + 0.4 * (kappa ** 4))

    v = min(v, r/2)

    if vel:
        v = vel

    omega = v * kappa

    return v, omega, r

if __name__ == '__main__':
    controller = MuleController()

    mule = TCPMule(controller.update)

    for timestep, _ in enumerate(mule.run()):
        if timestep == 1:
            mule.add_marker(waypoints[waypoint][0], waypoints[waypoint][1])

        x = mule.sensorData['position_x']
        y = mule.sensorData['position_z']

        gamma = math.radians(90 - mule.sensorData['rot_y']) # Clockwise to counter clockwise
        gamma = math.atan2(math.sin(gamma), math.cos(gamma))

        if transitioning:
            alpha = sigma_t(transitioning, tranisition_time)

            v_new, omega_new, distance = control_law(
                x, y, gamma,
                waypoints[waypoint][0],
                waypoints[waypoint][1],
                math.radians(90 - waypoints[waypoint][2]),
                vel=v_t,
            )

            omega = alpha * omega_old + (1 - alpha) * omega_new
            v = v_t

            transitioning -= 1
        else:
            v, omega, distance = control_law(
                x, y, gamma,
                waypoints[waypoint][0],
                waypoints[waypoint][1],
                math.radians(90 - waypoints[waypoint][2]),
            )

        controller.desired_velocity = v
        controller.desired_omega = math.degrees(omega)

        if distance < 1.5 and waypoint == len(waypoints) - 1:
            controller.brake_input = 0.1
            controller.desired_velocity = 0
            controller.desired_omega = 0

        controller.update(mule)

        if distance < 6 and waypoint != len(waypoints) - 1:
            waypoint += 1

            print waypoints[waypoint]
            mule.add_marker(waypoints[waypoint][0], waypoints[waypoint][1])

            transitioning = tranisition_time
            omega_old = omega
