import site; site.addsitedir("/usr/local/lib/python2.7/site-packages")

import time
import cv2

for i in range(0, 667):
    front = cv2.imread('./camera_data/center/{}.jpg'.format(i))
    cv2.imshow('Front camera', front)
    cv2.waitKey(100)
