from __future__ import division

import socket
import struct
import random

from PIL import Image

class TCPMule(object):
    brakeInput = 0
    rightDriveInput = 1
    leftDriveInput = 2
    rearDriveInput = 3
    steerInput = 4
    resetInput = 5

    sensors = {
        0L: "velocity_x",
        1L: "velocity_y",
        2L: "velocity_z",
        3L: "position_x",
        4L: "position_y",
        5L: "position_z",
        6L: "rot_x",
        7L: "rot_y",
        8L: "rot_z",
        100L: "fr_torque",
        101L: "fl_torque",
        102L: "r_torque",
        103L: "fr_rpm",
        104L: "fl_rpm",
        105L: "r_rpm",
        110L: "ultrasound_front1",
        111L: "ultrasound_front2",
        112L: "ultrasound_front3",
        113L: "ultrasound_rear1",
        114L: "ultrasound_rear2",
        115L: "ultrasound_rear3",
        116L: "ultrasound_left1",
        117L: "ultrasound_left2",
        118L: "ultrasound_right1",
        119L: "ultrasound_right2",
        120L: "collided",
        121L: "distance",
        122L: "time",
        123L: "steering_angle"
    }

    sensorUncertainty = {
        "velocity_x": 0.02,
        "velocity_y": 0.02,
        "velocity_z": 0.02,
        "position_x": 0.02,
        "position_y": 0.02,
        "position_z": 0.02,
        "rot_x": 0.25,
        "rot_y": 0.25,
        "rot_z": 0.25,
        "fr_torque": 1,
        "fl_torque": 1,
        "r_torque": 1,
        "fr_rpm": 0.3,
        "fl_rpm": 0.3,
        "r_rpm": 0.3,
        "ultrasound_front1": 0.05,
        "ultrasound_front2": 0.05,
        "ultrasound_front3": 0.05,
        "ultrasound_rear1": 0.05,
        "ultrasound_rear2": 0.05,
        "ultrasound_rear3": 0.05,
        "ultrasound_left1": 0.05,
        "ultrasound_left2": 0.05,
        "ultrasound_right1": 0.05,
        "ultrasound_right2": 0.05,
        "collided": 0,
        "distance": 0,
        "time": 0,
        "steering_angle": 0,
    }

    cameras = {
        200L: "front",
    }

    objectTypes = {               
        0L: "Background",
        1L: "Blockers",
        2L: "Walls",
        3L: "Roads",
        4L: "People",
        100L: "Unknown",
    }

    roadTypes = {
        1L: "straight",
        2L: "deadend",
        3L: "curve",
        4L: "sharpCurve",
        5L: "bendLeft",
        6L: "bendRight",
    }

    def __init__(self, callback):
        self.sensorData = {}
        self.cameraData = {}
        self.detectedObjects = {}
        self.roads = {}
        self.callback = callback

    def run(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.bind(('127.0.0.1', 6780))
        s.listen(1)

        self.conn, _ = s.accept()

        while 1:
            data = self.recv_bus_reqs()
            if not data: break

            self.update_sensors(data)

            yield True

        self.conn.close()

    def update_sensors(self, reqs):
        for req in reqs:
            if req[0] == 300L:
                self.detectedObjects = req[1]

            if req[0] == 400L:
                self.roads = req[1]

            if req[0] in self.sensors:
                uncertainty = self.sensorUncertainty[self.sensors[req[0]]]

                self.sensorData[self.sensors[req[0]]] = req[1]
                self.sensorData[self.sensors[req[0]]] += (random.random() - 0.5) * uncertainty

            if req[0] in self.cameras:
                self.cameraData[self.cameras[req[0]]] = req[1]

    def send_bus_req(self, var, val):
        val *= random.uniform(0.99, 1.01)

        self.conn.sendall(self.encode_bus_req(var, val))

    def recv_bus_reqs(self):
        reqs = []

        while True:
            req = self.recv_bus_req()

            if not req:
                return None

            if req[0] == 1000:
                return reqs

            reqs.append(req)

    def recv_bus_req(self):
        raw_var = self.recvall(8)

        var = self.decode_bus_var(raw_var)

        if var in self.cameras:
            width = self.decode_bus_var(self.recvall(8))
            height = self.decode_bus_var(self.recvall(8))
            val_len = self.decode_bus_var(self.recvall(8))

            val_raw = self.recvall(val_len)
            val = Image.frombytes('RGB', (width, height), val_raw, 'raw', 'RGB', 0, -1)
        # Omnipotent sensor
        elif var == 300:
            objects = self.decode_bus_var(self.recvall(8)) 

            val = []

            for _ in range(0, objects):
                objtype = self.decode_bus_var(self.recvall(8))
                center_x = self.decode_bus_val(self.recvall(8))
                center_y = self.decode_bus_val(self.recvall(8))
                center_z = self.decode_bus_val(self.recvall(8))
                extents_x = self.decode_bus_val(self.recvall(8))
                extents_y = self.decode_bus_val(self.recvall(8))
                extents_z = self.decode_bus_val(self.recvall(8))

                val.append({
                    "type": self.objectTypes[objtype],
                    "center": [center_x, center_y, center_z],
                    "extents": [extents_x, extents_y, extents_z],
                })
        # Road sensor
        elif var == 400:
            val = []

            while self.decode_bus_var(self.recvall(8)) == 0:
                objtype = self.decode_bus_var(self.recvall(8))
                pos_x = self.decode_bus_val(self.recvall(8))
                pos_y = self.decode_bus_val(self.recvall(8))
                pos_z = self.decode_bus_val(self.recvall(8))
                rot_x = self.decode_bus_val(self.recvall(8))
                rot_y = self.decode_bus_val(self.recvall(8))
                rot_z = self.decode_bus_val(self.recvall(8))

                new_val = {
                    "type": self.roadTypes[objtype],
                    "pos": [pos_x, pos_y, pos_z],
                    "rot": [rot_x, rot_y, rot_z],
                }

                if new_val not in val:
                    val.append(new_val)
        else:
            val = self.recvall(8)
            val = self.decode_bus_val(val)

        return (var, val)

    def recvall(self, bufsize):
        buf = ""

        while len(buf) < bufsize:
            new_buf = self.conn.recv(bufsize - len(buf))
            if not new_buf: return None
            buf += new_buf

        return buf

    def encode_bus_req(self, var, val):
        return struct.pack('@Qd', var, val)

    def decode_bus_var(self, var):
        return struct.unpack("@Q", var)[0]

    def decode_bus_val(self, val):
        return struct.unpack("@d", val)[0]

    def reset(self):
        self.send_bus_req(self.resetInput, 0)

    def manual_input(self):
        self.conn.sendall(self.encode_bus_req(6, 1))

    def add_marker(self, x, y):
        self.conn.sendall(self.encode_bus_req(7, x))
        self.conn.sendall(self.encode_bus_req(8, y))
