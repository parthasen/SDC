from __future__ import division

class PID(object):
    def __init__(self, kp, ki, kd, timestep=0.05):
        self.kp = kp
        self.kd = kd * timestep
        self.ki = ki * timestep

        self.integral = 0
        self.olderror = 0
    
    def update(self, error):
        self.integral += error

        kp = self.kp * error
        ki = self.ki * self.integral
        kd = self.kd * (error - self.olderror)

        self.olderror = error

        return kp + ki + kd

    def reset(self):
        self.integral = 0
        self.olderror = 0
