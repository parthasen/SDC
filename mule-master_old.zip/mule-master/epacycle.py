import csv

class EPACycle(object):
    def __init__(self, cycle):
        self.cycle = cycle

        self.speeds = []

        with open('{}.csv'.format(cycle), 'rb') as f:
            for line in f:
                self.speeds.append(float(line.split()[1]))

    def timestep(self, timestep):
        return self.speeds[timestep // 10] / 3.6

    def distance(self, timestep):
        distance = 0

        for i in range(0, timestep):
            distance += self.timestep(i) * 0.1

        return distance

if __name__ == '__main__':
    cycle = EPACycle("epa_urban", 0.5)

    timestep = 0

    while True:
        cycle.timestep(timestep)
        timestep += 1
