from unity_server import Mule
from pid import PID

import math
import numpy as np

class BrakingTestController(object):
    def __init__(self):
        self.timestep = 0
        print "z,vel"

    def update(self, mule):
        if self.timestep < 100:
            mule.send_bus_req(mule.rightDriveInput, 1)
            mule.send_bus_req(mule.leftDriveInput, 1)
            mule.send_bus_req(mule.rearDriveInput, 1)
            mule.send_bus_req(mule.brakeInput, 0)

        if self.timestep > 100:
            mule.send_bus_req(mule.rightDriveInput, 0)
            mule.send_bus_req(mule.leftDriveInput, 0)
            mule.send_bus_req(mule.rearDriveInput, 0)

            mule.send_bus_req(mule.brakeInput, 1)

        print "{}, {}".format(mule.sensorData['position_z'], mule.sensorData['velocity_z'])

        self.timestep += 1


if __name__ == '__main__':
    controller = BrakingTestController()
    mule = Mule(controller.update)
    mule.run()
