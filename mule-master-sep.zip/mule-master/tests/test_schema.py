import ati.schema as schema
import google
import pytest

testCases = [
    ("mule.odometry", schema.OdometryUpdate(
        Position=schema.Vector(x=1, y=2, z=3),
        Velocity=schema.Vector(x=1, y=2, z=3),
        Welocity=schema.Vector(x=1, y=2, z=3),
        Angle=schema.Vector(x=1, y=2, z=3),
        OmegaLeft=7.9,
        OmegaRight=3.23)
    ),
    ("mule.vehicle.controls", schema.VehicleControls(
        LeftThrottle=1.23, 
        RightThrottle=2.23, 
        BrakeInput=3.23, 
        SteeringAngle=4.23)
    ),
    ("mule.vehicle.timestep", schema.Timestep(Timestep=384023)),
    ("mule.command", schema.MuleCommand(Command="hello")),
    ("mule.status", schema.MuleStatus(Status="world")),
    ("mule.perception.objects", schema.DetectedObjects(
            objects=[
                schema.Object(
                    type=schema.UNKNOWN,
                    position=schema.Vector(x=2, y=3, z=4),
                    extents=schema.Vector(x=7, y=8, z=9),
                ),
                schema.Object(
                    type=schema.PEDESTRIAN,
                    position=schema.Vector(x=5, y=3, z=1),
                    extents=schema.Vector(x=12, y=9, z=23),
                ),
            ]
        )
    ),
    ("mule.perception.roads", schema.DetectedRoads(lanes=[
        schema.Lane(areas=[
            schema.Polygon(edges=[
                schema.Vector(x=1, y=2, z=3),
                schema.Vector(x=1, y=2, z=3),
                schema.Vector(x=1, y=2, z=3),
            ]),
            schema.Polygon(edges=[
                schema.Vector(x=1, y=2, z=3),
                schema.Vector(x=1, y=2, z=3),
                schema.Vector(x=1, y=2, z=3),
            ]),
        ]),
        schema.Lane(areas=[
            schema.Polygon(edges=[
                schema.Vector(x=1, y=2, z=3),
                schema.Vector(x=1, y=2, z=3),
                schema.Vector(x=1, y=2, z=3),
            ]),
        ]),
    ])),
    ("mule.perception.lidar", schema.LIDARPoint(
            vertical_angles=(1.0, 2.0, 3.0, 4.0),
            horizontal_angles=(0.1, 0.2, 0.3, 0.4),
            distances=(1, 2, 3, 4, 3, 2, 1, 0, 5, 6, 7, 8, 9, 8, 7, 6),
            intensities=(1, 2, 3, 4, 3, 2, 1, 0, 5, 6, 7, 8, 9, 8, 7, 6),
        )
    )
]

def test_codec():
    for testCase in testCases:
        topic, message = testCase

        packet = schema.encode_message(topic, message)
        out_topic, out_message = schema.decode_message(packet)

        assert out_topic == topic
        assert out_message == message

def test_invalid_message():
    with pytest.raises(google.protobuf.message.DecodeError):
        schema.decode_message(b"mule.command" + bytes([0, 32, 45, 32, 3, 4]))

def test_malformed_message():
    with pytest.raises(schema.InvalidMessage):
        schema.decode_message(bytes([0x3, 0x3]))

def test_invalid_topic():
    with pytest.raises(schema.InvalidTopic):
        schema.decode_message(b"INVALID-topic" + bytes([0, 32, 45, 32, 3, 4]))
