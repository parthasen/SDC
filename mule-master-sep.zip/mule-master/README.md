# Installation Guide

Install Golang and dep via:

```
brew install go dep
```

On Linux, download `go` from https://golang.org/doc/install and `dep` from https://github.com/golang/dep/releases.

Install the python package and dependencies by running:

```
pip install -e ".[dev]"
```

To build the project, run `make build`. To run unit tests, run `make test`

If you want to modify the schema files, you have to install `protoc`. Run `brew install protobuf`. 

If you are on Linux, install it from https://github.com/google/protobuf. (Don't use apt-get as it has an outdated version) 

DO NOT install the language libraries for Protobuf, only protoc. We automatically download Python and Go dependencies.
