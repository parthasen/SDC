# schema

Schema for data transmitted over ZeroMQ bus. If you add a new message, remember to update `wire.go`, `wire_test.go` and `__init__.py`.