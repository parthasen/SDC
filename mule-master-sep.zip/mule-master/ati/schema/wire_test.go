package schema

import (
	"github.com/golang/protobuf/proto"
	"testing"
	"reflect"
	"fmt"
)

type testCase struct {
	topic   string
	message proto.Message
}

var testCases = []testCase{
	{
		topic: "mule.odometry",
		message: &OdometryUpdate{
			Position: &Vector{1, 2, 3},
			Velocity: &Vector{4, 5, 6},
			Welocity: &Vector{7, 8, 9},
			Angle   : &Vector{10, 11, 12},
			OmegaLeft : 33.23,
			OmegaRight: 12.99,
		},
	},
	{
		topic: "mule.vehicle.controls",
		message: &VehicleControls{
			LeftThrottle : 1.23,
			RightThrottle: 2.23,
			BrakeInput   : 3.23,
			SteeringAngle: 4.23,
		},
	},
	{
		topic: "mule.vehicle.timestep",
		message: &Timestep{
			Timestep: 384023,
		},
	},
	{
		topic: "mule.command",
		message: &MuleCommand{
			Command: "test_command",
		},
	},
	{
		topic: "mule.status",
		message: &MuleStatus{
			Status: "test_status",
		},
	},
	{
		topic: "mule.perception.objects",
		message: &DetectedObjects{
			Objects: []*Object {
				&Object{
					Type: ObjectType_UNKNOWN,
					Position: &Vector{2, 3, 4},
					Extents: &Vector{7, 8, 9},
				},
				&Object{
					Type: ObjectType_PEDESTRIAN,
					Position: &Vector{5, 3, 1},
					Extents: &Vector{12, 9, 23},
				},
			},
		},
	},
	{
		topic: "mule.perception.roads",
		message: &DetectedRoads{ []*Lane{
			&Lane { []*Polygon{
				&Polygon{ []*Vector{
					&Vector{1, 2, 3}, &Vector{4, 5, 6}, &Vector{7, 8, 9},
				}},
				&Polygon{ []*Vector{
					&Vector{1, 2, 3}, &Vector{4, 5, 6}, &Vector{7, 8, 9},
				}},
			}},
			&Lane { []*Polygon{
				&Polygon{ []*Vector{
					&Vector{1, 2, 3}, &Vector{4, 5, 6}, &Vector{7, 8, 9},
				}},
				&Polygon{ []*Vector{
					&Vector{1, 2, 3}, &Vector{4, 5, 6}, &Vector{7, 8, 9},
				}},
			}},
		}},
	},
	{
		topic: "mule.perception.lidar",
		message: &LIDARPoint{
			VerticalAngles: []float64{1.0, 2.0, 3.0, 4.0},
			HorizontalAngles: []float64{0.1, 0.2, 0.3, 0.4},
			Distances: []float64{1, 2, 3, 4, 3, 2, 1, 0, 5, 6, 7, 8, 9, 8, 7, 6},
			Intensities: []float64{1, 2, 3, 4, 3, 2, 1, 0, 5, 6, 7, 8, 9, 8, 7, 6},
		},
	},

}

func TestCodec(t *testing.T) {
	for _, testCase := range testCases {
		t.Run(fmt.Sprintf("Topic %s", testCase.topic), func(t *testing.T) {
			packet, err := EncodeMessage(testCase.topic, testCase.message)

			if err != nil {
				t.Errorf("Unable to encode %s message: %s", testCase.topic, err)
			}

			topic, message, err := DecodeMessage(packet)

			if err != nil {
				t.Errorf("Unable to decode %s message: %s", testCase.topic, err)
			}

			if topic != testCase.topic {
				t.Errorf("Mismatch in topic: %s != %s", topic, testCase.topic)
			}

			if !reflect.DeepEqual(message, testCase.message) {
				t.Errorf("Mismatch in message: %+v != %+v", message, testCase.message)
			}
		})
	}
}

func TestInvalidMessage(t *testing.T) {
	packet := append([]byte("mule.odometry"), '\000', 32, 43, 32)

	_, _, err := DecodeMessage(packet)

	if err == nil {
		t.Errorf("Didn't receive error from invalid message")
	}
}

func TestMalformedMessage(t *testing.T) {
	packet := []byte("mule.odometry")

	_, _, err := DecodeMessage(packet)

	if err == nil {
		t.Errorf("Didn't receive error from malformed message")
	}
}

func TestInvalidTopic(t *testing.T) {
	packet := append([]byte("INVALID-topic"), '\000', 32, 45, 32, 3, 4)

	_, _, err := DecodeMessage(packet)

	if err == nil {
		t.Errorf("Didn't receive error from invalid topic")
	}
}
