class SmoothFollow {
    constructor(camera, target) {
        this.distance = 10;
        this.height = 5;
        this.heightMultiplier = 0;
        this.heightDamping = 2;
        this.followVelocity = true;
        this.velocityDamping = 5;

        this.smoothLastPos = new THREE.Vector3();
        this.smoothVelocity = new THREE.Vector3(2, 0, 0);
        this.smoothTargetAngle = target.rotation.y;

        this.smoothLastPos.copy(target.position)
        this.smoothVelocity.copy(target.position)

        this.target = target
        this.camera = camera
    }
    
    update(deltat) {
        if (isNaN(deltat))
            return;

        const updatedVelocity = new THREE.Vector3();

        updatedVelocity.subVectors(this.target.position, this.smoothLastPos);
        updatedVelocity.divideScalar(deltat);

        this.smoothLastPos.copy(this.target.position);

        updatedVelocity.y = 0;

        if (updatedVelocity.length() > 1)
        {
            this.smoothVelocity.lerp(updatedVelocity, this.velocityDamping * deltat)
            this.smoothTargetAngle = Math.atan2(this.smoothVelocity.x, this.smoothVelocity.z);
        }

        if (!this.followVelocity)
            this.smoothTargetAngle = this.target.rotation.y;

        const wantedHeight = this.target.position.y + this.height;
        var currentRotationAngle = this.camera.rotation.y;
        var currentHeight = this.camera.position.y;
    
        const rotationLerp = THREE.Math.clamp(this.rotationDamping * deltat, 0, 1);
        const heightLerp = THREE.Math.clamp(this.heightDamping * deltat, 0, 1);
    
        currentRotationAngle += (this.smoothTargetAngle - currentRotationAngle) * rotationLerp;
        currentHeight += (wantedHeight - currentHeight) * heightLerp;

        const currentRotation = new THREE.Euler(0, currentRotationAngle, 0);

        this.camera.position.copy(this.target.position);
        this.camera.position.sub(new THREE.Vector3(0, 0, 1 * this.distance).applyEuler(currentRotation));

        this.camera.position.y = currentHeight;

        const heightVector = new THREE.Vector3(0, this.height * this.heightMultiplier, 0);

        this.camera.lookAt(heightVector.add(this.target.position));
    }
}
