var renderer = new THREE.WebGLRenderer();
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

var scene = new THREE.Scene();
var camera = new THREE.PerspectiveCamera(55, window.innerWidth/window.innerHeight, 0.1, 1000);

camera.position.z = 5;

var orbit_controls = new THREE.OrbitControls(camera);

// orbit_controls.minDistance = 5;
// orbit_controls.maxDistance = 9;

var gridHelper = new THREE.GridHelper(1000, 1000);
scene.add(gridHelper);

var geometry = new THREE.BoxGeometry(1, 1, 2);
var material = new THREE.MeshBasicMaterial({ color: 0x660000 });
var cube = new THREE.Mesh(geometry, material);
scene.add(cube);

orbit_controls.target = cube.position;
// var follower = new SmoothFollow(camera, cube);

const extrudeSettings = {
    amount: 0.01, 
    bevelEnabled: false,
};

// var road_geometry = new THREE.ExtrudeBufferGeometry([], extrudeSettings);
// var road_mesh = new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color: 0xeeeeee}));
// scene.add(road_mesh);

var covered_areas = [];

var data_socket = new WebSocket("ws://" + document.location.host + "/sub");

var first = true;


data_socket.onmessage = function(event) {
    var packet = JSON.parse(event.data);

    if (packet.Topic == "mule.odometry") {
        cube.position.x = packet.Message.Position.x;
        cube.position.y = packet.Message.Position.z;
        cube.position.z = packet.Message.Position.y;
    
        cube.rotation.x = Math.PI/2 - packet.Message.Angle.x;
        cube.rotation.y = Math.PI/2 - packet.Message.Angle.z;
        cube.rotation.z = Math.PI/2 - packet.Message.Angle.y;
    }

    if (packet.Topic === "mule.perception.roads") {
        // if (!first)
        //     return;

        const areas = packet.Message.lanes[0].areas;
        
        const indices = [];
        const vertices = [];
        const normals = [];

        var vertices_offset = 0;

        for (var i = 0; i < areas.length; i++) {

            var edges = areas[i].edges;
            
            if (THREE.ShapeUtils.isClockWise(edges) === false)
                edges = edges.reverse();
            
            const v_edges = [];

            for (var j = 0; j < edges.length; j++) {
                v_edges.push(new THREE.Vector2(edges[j].x, edges[j].y));
            }

            const faces = THREE.ShapeUtils.triangulateShape(v_edges, []);

            for (j = 0; j < v_edges.length; j++) {
                const vertex = v_edges[j];
                
                vertices.push(vertex.x, 0, vertex.y);
                normals.push(0, -1, 0);
            }
            
            for (j = 0; j < faces.length; j++) {
                var a = faces[j][0] + vertices_offset;
                var b = faces[j][1] + vertices_offset;
                var c = faces[j][2] + vertices_offset;

                indices.push(a, b, c);
            }
        
            vertices_offset += v_edges.length;

        }

        var road_geometry = new THREE.BufferGeometry();

        const g_vertices = new Float32Array(vertices);
        const g_normals = new Float32Array(normals);

        road_geometry.setIndex(indices);
        road_geometry.addAttribute('position', new THREE.BufferAttribute(g_vertices, 3));
        road_geometry.addAttribute('normal', new THREE.BufferAttribute(g_normals, 3));

        var road_material = new THREE.MeshBasicMaterial({color: 0x00ff00, side: THREE.DoubleSide});
        var road_mesh = new THREE.Mesh(road_geometry, road_material);

        scene.add(road_mesh);

        console.log(road_geometry);

        first = false;
    }
};

var old_time = 0;

var animate = function(new_time) {
    const dt = new_time - old_time;
    old_time = new_time;

    requestAnimationFrame(animate);
    
    // follower.update(dt/1000);

    renderer.render(scene, camera);
};

animate();
