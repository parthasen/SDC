package main

import (
	"os"
	"log"
	"time"
	"net/http"
	"ati/schema"

	zmq "github.com/pebbe/zmq4"
	"github.com/gorilla/mux"
	"github.com/gorilla/handlers"
	"github.com/gorilla/websocket"
	"github.com/golang/protobuf/proto"
)

var upgrader = websocket.Upgrader{
	ReadBufferSize:  1024,
	WriteBufferSize: 1024,
}

type Message struct {
	Topic string
	Message proto.Message
}

type MQProxy struct {
	channels map[chan Message]int
}

func NewProxy() *MQProxy {
	return &MQProxy {
		channels: map[chan Message]int{},
	}
}

func (s *MQProxy) Proxy(w http.ResponseWriter, r *http.Request) {
	conn, err := upgrader.Upgrade(w, r, nil)

	channel := make(chan Message, 16)

	s.channels[channel] = 1

	defer delete(s.channels, channel)

	if err != nil {
		log.Printf("MQProxy: upgrader.Upgrade: %s", err)
		return
	}

	for {
		message := <- channel

		err := conn.WriteJSON(message)

		if err != nil {
			log.Printf("MQProxy: conn.WriteJSON: %s", err)
			return
		}
	}
}

func (s *MQProxy) Sub() {
	sub := os.Getenv("ATI_SUB")

	socket, _ := zmq.NewSocket(zmq.SUB)
	defer socket.Close()

	if err := socket.Connect(sub); err != nil {
		log.Fatalf("Unable to open SUB socket at %s: %s", sub, err)
	}

	socket.SetSubscribe("mule")

	for {
		packet, _ := socket.RecvBytes(0)

		topic, message, err := schema.DecodeMessage(packet)

		if err != nil {
			log.Fatalf("Unable to decode message: %s", err)
		}

		for c, _ := range s.channels {
			c <- Message{Topic: topic, Message: message}
		}
	}
}

func main() {
	log.SetPrefix("[visualizer] ")

	proxy := NewProxy()

	go proxy.Sub()

	r := mux.NewRouter()

	r.HandleFunc("/sub", proxy.Proxy)
	r.PathPrefix("/").Handler(http.FileServer(http.Dir("./ati/visualizer/static")))

	srv := &http.Server{
		Handler:      handlers.LoggingHandler(os.Stdout, r),
		Addr:         "127.0.0.1:8000",
		WriteTimeout: 15 * time.Second,
		ReadTimeout:  15 * time.Second,
	}

	log.Fatal(srv.ListenAndServe())
}
