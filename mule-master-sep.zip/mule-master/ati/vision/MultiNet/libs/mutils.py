import os
import numpy as np
from PIL import Image
import cv2

# mutils = imp.load_source('module.name', '/home/anand/Workspace/src/private/python/mutils.py')
fname_foo = 'foo.jpg'
tmp_dir = '/tmp'

def get_fpath(fname):
    return os.path.join(tmp_dir, fname)

def save_2x4(img, is16Bit = True, fname=fname_foo):
    #Image.fromarray(img.astype('int32') * 255).convert('RGB').save('foo.jpg')
    if is16Bit:
        img = img / (2 ** 8)
    
    #img = np.delete(img, 0, 2)
    img = img.astype(np.uint8)
    Image.fromarray(img).save(get_fpath(fname))

def save_2x3(img, is16Bit = True, fname=fname_foo):
    if is16Bit:
        img = img / (2 ** 8)
    img = img.astype(np.uint8)
    Image.fromarray(img).save(get_fpath(fname))
   
def save_2x1(img, fname=fname_foo):
    Image.fromarray(img).save(get_fpath(fname))

def save_1x1(arr_1d, fname=fname_foo, w=28, h=28):
    save_2x1(arr_1d.reshape(w, h), fname=fname)

def print_deltas(time_values):
    if (len(time_values) < 2):
        return

    print("Time deltas are:")
    previous_value = time_values[0]
    for time_value in time_values[1:]:
        if type(time_value) == type(""):
            print(time_value)
        else:
            delta = time_value - previous_value
            previous_value = time_value
            print(delta)
    
