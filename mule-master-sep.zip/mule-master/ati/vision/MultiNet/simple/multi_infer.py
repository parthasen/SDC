import os
import sys
import json
import numpy as np
from PIL import Image
from scipy.misc import imresize, imsave, toimage
import tensorflow as tf

import objective
import architecture

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3' 
script_path = os.path.dirname(os.path.realpath(__file__))
hypes_path = os.path.join(script_path, 'hypes.json')
sys.path.insert(1, script_path)

def build_network(hypes):
    image_pl = tf.placeholder(tf.float32)
    image = tf.expand_dims(image_pl, 0)
    image.set_shape([1, 384, 1248, 3])
    logits = architecture.inference(hypes, image, train=False)
    dec = objective.decoder(hypes, logits, train=False)
    return dec, image_pl

def run_network(dec, image_pl, inf):
    ss = tf.get_default_session()

    im = imresize(Image.open(inf), (384, 1248, 3), interp='cubic')
    output = ss.run(dec['softmax'], {image_pl: im})
    mask = output[:, 1].reshape(384, 1248)
    return mask, im

def infer(inf, hypes, network=None):
    if network:
        [decoder, image_pl] = network
    else:
        decoder, image_pl = build_network(hypes)
    
    mask, im = run_network(decoder, image_pl, inf)
    return mask, im

def train(inf, maskf, hypes):
    image_pl = tf.placeholder(tf.float32)
    image = imresize(Image.open(inf), (384, 1248, 3), interp='cubic')
    exp_image = tf.expand_dims(np.asarray(image, np.float32), 0)

    road_mask = np.zeros((384,1248,2))
    mask = imresize(Image.open(maskf), (384, 1248, 3), interp='cubic')
    
    road_mask[:,:,0] = mask[:,:,0]     # RED channel
    road_mask[:,:,1] = mask[:,:,2]     # BLUE channel

    np.reshape(road_mask,(1248,384,2))
    logits = architecture.inference(hypes, exp_image, train=True)
    decoder = objective.decoder(hypes, logits, train=True)
    losses = objective.loss(hypes,
                            decoder,
                            road_mask)

    loss = losses['total_loss']
    opt = tf.train.AdamOptimizer(learning_rate=0.1, epsilon=0.01)
    grads = opt.compute_gradients(loss)
    train_op = opt.apply_gradients(grads)
    
    ss = tf.InteractiveSession()
    ss.run([tf.global_variables_initializer()])
    ss.run(train_op, {image_pl: image})
    
def overlay(input_image,
            segmentation,
            color=[0, 255, 0, 127]):
    color = np.array(color).reshape(1, 4)
    
    img = (segmentation * 255).astype(np.uint8)
    img = img.reshape(input_image.shape[0], input_image.shape[1], 1)
    img = np.dot(img, color)

    background = toimage(input_image)
    output = toimage(img, mode="RGBA")
    background.paste(output, box=None, mask=output)
    
    return np.array(background)
    
def get_road_mask_ex(inf,
                     outf,
                     out_maskf=None,
                     segmentation_threshold=0.5,
                     network=None):
    hypes = json.load(open(hypes_path))

    if network:
        tf.get_variable_scope().reuse_variables()
        
    mask, im  = infer(inf, hypes, network)
    road_mask = mask > segmentation_threshold

    if out_maskf:
        shape = road_mask.shape
        color = np.array([0, 255, 0, 127]).reshape(1, 4)
        road_maski = road_mask.reshape(shape[0], shape[1], 1)
        road_maski = np.dot(road_maski, color).astype(np.uint8)
        Image.fromarray(road_maski).save(out_maskf)

    imsave(outf, overlay(im, road_mask))
    return

def get_multinet():
    hypes = json.load(open(hypes_path))
    decoder, image_pl = build_network(hypes)
    ss = tf.InteractiveSession()
    ss.run(tf.global_variables_initializer())
    tf.train.Saver().restore(ss,
            '/home/src/autonomy/MultiNet/RUNS/MultiNet_ICCV/model.ckpt-99999')
    
    return [decoder, image_pl]

def main():
    inf = '/home/data/IIScRoadImages/multinet_train/iiscroad_and_mask/G0031379.png'
    maskf = '/home/data/IIScRoadImages/multinet_train/iiscroad_and_mask/G0031379_mask.png'
    #inf = '/home/src/autonomy/MultiNet/data/demo/um_000005.png'
    hypes = json.load(open(hypes_path))
    #get_road_mask_ex(sys.argv[1], sys.argv[2], sys.argv[3])
    #infer(inf, hypes)
    train(inf, maskf, hypes)

if __name__ == '__main__':
    main()
