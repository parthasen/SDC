import os
import sys
import json
import numpy as np
from PIL import Image
from scipy.misc import imresize, imsave, toimage
import tensorflow as tf

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3' 
script_path = os.path.dirname(os.path.realpath(__file__))
hypes_path = os.path.join(script_path, 'hypes.json')
sys.path.insert(1, script_path)

import objective
import architecture
import multi_infer as mn

def batch_run():
    hypes = json.load(open(hypes_path))
    INPUT_DIR = '/home/data/IIScRoadImages/multinet_train/input/'
    MASK_DIR = '/home/data/IIScRoadImages/multinet_train/mask/'
    for fileName in os.listdir(INPUT_DIR):
        base, ext = os.path.splitext(fileName)
        inf = INPUT_DIR + fileName
        maskf = MASK_DIR + base+ "_mask.png" 
        print inf, maskf
        mn.train(inf, maskf, hypes)

def main():
    batch_run()
if __name__ == '__main__':
    main()
