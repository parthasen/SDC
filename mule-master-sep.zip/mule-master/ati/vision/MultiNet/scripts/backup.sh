#!/bin/bash

cp submodules/TensorVision/tensorvision/utils.py mirror/utils.py 

cp submodules/tensorflow-fcn/fcn32_vgg.py mirror/fcn32_vgg.py
cp submodules/tensorflow-fcn/fcn16_vgg.py mirror/fcn16_vgg.py
cp submodules/tensorflow-fcn/fcn8_vgg.py mirror/fcn8_vgg.py
