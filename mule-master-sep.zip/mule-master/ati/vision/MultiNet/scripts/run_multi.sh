#!/bin/bash

function crop_images() {
    ls -1 /home/data/gopro_data/iisc/*.jpg | while read line; do sudo python imsaver.py $line ${line%.jpg}_multi.jpg; done
}

# output: ~/downloads/image-1198_out.png
# weights (downloaded by demo.py) at: MultiNet/RUNS/MultiNet_ICCV
function run_multi() {
    python demo.py --gpus 0 --input ~/downloads/image-1198.png
}

for ff in /tmp/iisc/8th/*.JPG; do
    python imsaver.py $ff ${ff%.JPG}_multi.png
    python demo.py --gpus 0 --input ${ff%.JPG}_multi.png
done

