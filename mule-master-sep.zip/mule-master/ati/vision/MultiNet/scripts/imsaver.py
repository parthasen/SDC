import sys
from PIL import Image

def convert(imIn):
    return imIn.convert("RGB")

def resize(imIn):
    width = imIn.size[0]
    height = imIn.size[1]
    print("width = ", width)
    print("height = ", height)
    left = width - 1248
    top = height - 384

    return imIn.crop((left, top, width, height))

def save_rgb(inf, outf):
    im = Image.open(inf)
    convert(im).save(outf)

def resize_convert(inf, outf):
    convert(resize(Image.open(inf))).save(outf)

def resize_raw(inf, outf):
    im = Image.open(inf)

    width = im.size[0]
    height = 500 # crop from im.size[1]
    im = im.crop((0, 0, width, 500))

    newWidth = 1248
    newHeight = int((1.0 * height) * newWidth / width)
    print("new height = ", newHeight)
    print("new width = ", newWidth)
    im.thumbnail((newWidth, newHeight))

    croppedWidth = newWidth
    croppedHeight = 384
    print("cropped height = ", croppedHeight)
    print("cropped width = ", croppedWidth)
    im = im.crop((newWidth - croppedWidth, newHeight - croppedHeight,
                  newWidth, newHeight))

    im.save(outf)
    
def resize_iphone(inf, outf):
    im = Image.open(inf)

    width = im.size[0]
    height = im.size[1]

    height1 = height - 900
    im = im.crop((0, 0, width, height1))

    im = im.crop((0, 600, width, height1))

    finalWidth = 1248
    finalHeight = 384
    im.thumbnail((finalWidth, finalHeight))

    im.save(outf)

def nhresize(inf, outf):
    im = Image.open(inf)
    width = im.size[0]
    height = im.size[1]

    newHeight = int(384.0/1248 * width)
    removeHeight = (height - newHeight) / 2
    im = im.crop((0, removeHeight,
                   width, height - removeHeight))
    im.save(outf)


def test_save_rgb():
    save_rgb("/tmp/images/malles2.png",
             "/tmp/images/malles3.png")

def simple_multi_crop(inf, outf):
    imi = Image.open(inf)
    imo = im.crop((16, 116, 1264, 500))
    imo.save(outf)

def main():
    inf = sys.argv[1]
    outf = sys.argv[2]

    # convert = save_rgb(sys.argv[1], sys.argv[2])
    # convert = resize_convert(sys.argv[1], sys.argv[2])
    # convert  = resize_raw
    # convert = nhresize
    # convert = resize_iphone
    convert = simple_multi_crop
    
    convert(inf, outf)

main()
