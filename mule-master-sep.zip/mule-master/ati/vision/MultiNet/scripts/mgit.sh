#!/bin/bash

git status
pushd submodules/KittiBox
git status
pushd submodules/KittiClass
git status
pushd submodules/KittiSeg
git status
pushd tensorflow-fcn
git status
pushd TensorVision
git status

