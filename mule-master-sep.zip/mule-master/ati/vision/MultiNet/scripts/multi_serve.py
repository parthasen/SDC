import os
import sys
import numpy as np
from PIL import Image
import json
import pickle
import zmq

script_path=os.path.dirname(os.path.realpath(__file__))
multi_path=os.path.dirname(script_path)
lib_path=os.path.join(multi_path, 'simple')

sys.path.insert(1, script_path)
sys.path.insert(1, lib_path)

import multi_serve_config
from multi_infer import get_multinet, get_road_mask_ex

darkflow_home='/home/src/autonomy/darkflow/'
sys.path.insert(1, darkflow_home)
from darkflow.net.build import TFNet

def get_dark_network():
    darkflow_cfg = darkflow_home + "cfg/"
    darkflow_bin = darkflow_home + "bin/"
    options = {"config": darkflow_cfg,
               "model": darkflow_cfg + "yolo.cfg",
               "load": darkflow_bin + "yolo.weights",
               "threshold": 0.1, "gpu": 1.0}
    tfnet = TFNet(options)
    return tfnet

def process_dark_request(message, network):
    arg_list = json.loads(message)
    inf = arg_list[0]
    ima = np.asarray(Image.open(inf))
    result = network.return_predict(ima)
    
    return pickle.dumps(result)

def process_multi_request(message,
                          network):
    arg_list = json.loads(message)
    inf = arg_list[0]
    outf = arg_list[1]
    out_mask_name = None
    segmentation_threshold = 0.5
    if len(arg_list) > 2:
        out_mask_name = arg_list[2]
    if len(arg_list) > 3:
        segmentation_threshold = float(arg_list[3])

    if (os.path.exists(inf) and os.path.exists(os.path.dirname(outf))):
        get_road_mask_ex(
                inf,
                outf,
                out_maskf=out_mask_name,
                segmentation_threshold=segmentation_threshold,
                network=network)
        
        os.chmod(outf, 0666)
        response = "OK: {}".format(outf)
    else:
        response = "Not OK: cannot access infile or outfile. " \
                    "Consider using absolute paths since " \
                    "the service runs in a different user context."

    print(response)
    return response

def get_socket():
    context = zmq.Context()
    socket = context.socket(zmq.REP)
    socket.bind(multi_serve_config.multi_serve_socket)
    return socket

def process_request(socket, multinet=None, darknet=None):
    print("Wait for next request")
    message = socket.recv()

    print("Request = {}".format(message))
    try:
        arg_list = json.loads(message)
        if len(arg_list) == 1:
            response = process_dark_request(message, darknet)
        else:
            response = process_multi_request(message, multinet)

        socket.send(response)
    except Exception as ex:
        if ex.message:
            response = "Not OK: {}".format(ex.message)
        else:
            response = "Not OK: are the relevant output files writable ?"
        socket.send(response)
        print(response)

    return

def main():
    print("Initialize zeromq bus")
    socket = get_socket()

    print("Building multinet...")
    multinet = get_multinet()
    print("Building darkflow...")
    darknet = get_dark_network()

    print("Networks built. Starting process_request loop")
    while True:
        process_request(socket, multinet, darknet)

main()
