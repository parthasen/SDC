import os
import sys
import json
import pickle
import zmq

script_path=os.path.dirname(os.path.realpath(__file__))
sys.path.insert(1, script_path)

import multi_serve_config

def get_socket():
    context = zmq.Context()
    socket = context.socket(zmq.REQ)
    socket.connect(multi_serve_config.multi_client_socket)
    return socket

def do_request(request="1+1"):
    socket.send(request)
    return socket.recv()

def do_multi_request(inf,
                     outf,
                     out_maskf = None,
                     segmentation_threshold = 0.5,
                     socket = None):
    if not socket:
        socket = get_socket()
    request = [inf, outf, out_maskf]
    socket.send(json.dumps(request))
    return socket.recv()


def do_darkflow_request(inf, socket = None):
    if not socket:
        socket = get_socket()
    socket.send(json.dumps([inf]))
    return pickle.loads(socket.recv())

def main():
    if len(sys.argv) == 2:
        print(do_darkflow_request(sys.argv[1]))
    elif len(sys.argv) >= 3:
        out_maskf = None
        segmentation_threshold = 0.5
        
        if len(sys.argv) > 3:
            out_maskf = sys.argv[3]
        if len(sys.argv) > 4:
            segmentation_threshold = sys.argv[4]
            
        print(do_multi_request(sys.argv[1], sys.argv[2], out_maskf))
    else:
        print("Usage: multi_client.py infile outfile <opt:out_maskf>")
        sys.exit(0)
    

if __name__ == "__main__":
    main()
