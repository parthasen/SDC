#!/bin/bash

cp mirror/utils.py submodules/TensorVision/tensorvision/utils.py

cp mirror/fcn*_vgg.py incl/tensorflow_fcn
cp mirror/fcn*_vgg.py submodules/KittiBox/submodules/tensorflow-fcn
cp mirror/fcn*_vgg.py submodules/KittiClass/submodules/tensorflow-fcn
cp mirror/fcn*_vgg.py submodules/KittiSeg/submodules/tensorflow-fcn
cp mirror/fcn*_vgg.py submodules/tensorflow-fcn
