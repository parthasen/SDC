#!/bin/sh
# file belongs in /usr/bin/multi_serve_start.sh
# TODO the path to this script should be adjusted for the Jetson
python /home/src/autonomy/MultiNet/scripts/multi_serve.py
