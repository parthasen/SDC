from __future__ import division

from .low_control import MuleController

import math
import numpy as np

def triangle_check(p1, p2, p3):
    return (p1[0] - p3[0]) * (p2[1] - p3[1]) - (p2[0] - p3[0]) * (p1[1] - p3[1])

def ultrasound_obstructed(sensor_x, sensor_y, sensor_angle, reading, x, y):
    sensor_angle = math.radians(90 + sensor_angle)

    position = np.array([sensor_x, sensor_y])

    sin = np.sin(sensor_angle)
    cos = np.cos(sensor_angle)

    rotation = np.array([[cos, -sin], [sin, cos]])

    left  = np.array([6, -2])
    right = np.array([6,  2])

    position.shape = (2, 1)
    right.shape    = (2, 1)
    left.shape     = (2, 1)

    triangle = [position, position + np.dot(rotation, left), position + np.dot(rotation, right)]

    triangle[0].shape = (2)
    triangle[1].shape = (2)
    triangle[2].shape = (2)

    point = np.array([x, y])

    b1 = triangle_check(point, triangle[0], triangle[1]) < 0
    b2 = triangle_check(point, triangle[1], triangle[2]) < 0
    b3 = triangle_check(point, triangle[2], triangle[0]) < 0

    in_triangle = (b1 == b2) and (b2 == b3)

    magnitude = (x - sensor_x) ** 2 + (y - sensor_y) ** 2

    if in_triangle and magnitude > reading ** 2:
        return True
    else:
        return False

def local_grid(mule):
    grid = np.zeros((40, 20), dtype=bool)

    for y_index in range(0, 40):
        for x_index in range(0, 20):
            x = (x_index * 0.5) - 5
            y = (y_index * 0.5) - 10

            front1 = ultrasound_obstructed(-0.5, 1.05, -55, mule.sensorData['ultrasound_front1'], x, y)
            front2 = ultrasound_obstructed( 0.0, 1.05,   0, mule.sensorData['ultrasound_front2'], x, y)
            front3 = ultrasound_obstructed( 0.5, 1.05,  55, mule.sensorData['ultrasound_front3'], x, y)

            rear1 = ultrasound_obstructed(-0.5, -1.05, 235, mule.sensorData['ultrasound_rear1'], x, y)
            rear2 = ultrasound_obstructed( 0.0, -1.05, 180, mule.sensorData['ultrasound_rear2'], x, y)
            rear3 = ultrasound_obstructed( 0.5, -1.05, 125, mule.sensorData['ultrasound_rear3'], x, y)

            left1 = ultrasound_obstructed(-0.6,  0.3,  -80, mule.sensorData['ultrasound_left1'], x, y)
            left2 = ultrasound_obstructed(-0.6, -0.3, -100, mule.sensorData['ultrasound_left2'], x, y)

            right1 = ultrasound_obstructed(0.6,  0.3,  80, mule.sensorData['ultrasound_right1'], x, y)
            right2 = ultrasound_obstructed(0.6, -0.3, 100, mule.sensorData['ultrasound_right2'], x, y)

            obstructed = front1 or front2 or front3
            obstructed = obstructed or rear1 or rear2 or rear3

            obstructed = obstructed or right1 or right2
            obstructed = obstructed or left1 or left2

            grid[y_index][x_index] = not obstructed

    return grid
