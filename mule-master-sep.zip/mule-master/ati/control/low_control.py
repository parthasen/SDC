from .pid import PID

import ati.schema as schema
import math

track_width = 0.8
wheelbase = 1.5

tire_radius = 0.3

class WheelController(object):
    wheel_kp =  0.15
    wheel_ki =  0.02
    wheel_kd =  0.0

    def __init__(self):
        self.left_wheel_pid  = PID(self.wheel_kp, self.wheel_ki, self.wheel_kd)
        self.right_wheel_pid = PID(self.wheel_kp, self.wheel_ki, self.wheel_kd)

        self.desired_omega = 0
        self.desired_velocity = 0

        self.brake_input = 0

    def turning_radius(self, velocity):
        return velocity**2/8 # Mule can handle 11 m/s^2, safety factor

    def update(self, odometry):
        v = math.fabs(self.desired_velocity)
        omega = math.fabs(self.desired_omega)

        if omega:
            r = v/omega

            v_l = omega * (r - track_width / 2.)
            v_r = omega * (r + track_width / 2.)

            steer_angle = math.atan2(wheelbase, r)
        else:
            v_r = v
            v_l = v

            steer_angle = 0

        v_l = v_l/tire_radius
        v_r = v_r/tire_radius

        if self.desired_omega < 0:
            v_l, v_r = v_r, v_l

            steer_angle = -steer_angle

        if self.desired_velocity < 0:
            v_l, v_r = -v_r, -v_l

            steer_angle = -steer_angle

        # Low level controllers
        rightThrottle = self.right_wheel_pid.update(v_r - odometry.omega_right)
        leftThrottle  =  self.left_wheel_pid.update(v_l - odometry.omega_left)

        rightThrottle = max(min(rightThrottle, 1), -1)
        leftThrottle = max(min(leftThrottle, 1), -1)

        if math.fabs(rightThrottle) < 0.005:
            rightThrottle = 0

        if math.fabs(leftThrottle) < 0.005:
            leftThrottle = 0

        return schema.VehicleControls(
            RightThrottle=rightThrottle,
            LeftThrottle=leftThrottle,
            BrakeInput=self.brake_input,
            SteeringAngle=-steer_angle
        )

    def reset(self):
        self.left_wheel_pid.reset()
        self.right_wheel_pid.reset()

        self.desired_omega = 0
        self.desired_velocity = 0

        self.brake_input = 0
