from __future__ import division

import math
import sys
import os

sys.path.append(os.path.abspath('.'))

from mule.low_control import MuleController
from mule.bridge import TCPMule
from mule.utils import PID

if __name__ == '__main__':
    target_x = 50
    target_z = 150

    controller = MuleController()

    controller.desired_velocity = 10.

    mule = TCPMule(controller.update)

    phi_controller = PID(0.5, 0.1, 0)

    for timestep, _ in enumerate(mule.run()):
        x_diff = target_x - mule.sensorData['position_x']
        y_diff = target_z - mule.sensorData['position_z']

        magnitude = math.sqrt(x_diff ** 2 + y_diff ** 2)

        controller.desired_velocity = min(10, magnitude/3)

        desired_phi = math.degrees(math.atan2(x_diff, y_diff))

        # Get heading error
        phi_e = math.radians(desired_phi - mule.sensorData['rot_y'])

        phi_e = math.atan2(math.sin(phi_e), math.cos(phi_e))

        controller.desired_omega = math.degrees(min(
            phi_controller.update(phi_e), 
            8/controller.desired_velocity # a_y / v gives you max omega
        ))

        if magnitude < 5:
            mule.send_bus_req(mule.rightDriveInput, 0)
            mule.send_bus_req( mule.leftDriveInput, 0)

            mule.send_bus_req(mule.brakeInput, 1)

            mule.send_bus_req(mule.steerInput, 0)

            print "ARRIVED!"

            break

        controller.update(mule)
