from __future__ import division

import math
import sys
import os

sys.path.append(os.path.abspath('.'))

from mule.path_control import PathController, PathSegment
from mule.low_control import MuleController
from mule.bridge import TCPMule
from mule.utils import PID

if __name__ == '__main__':
    mule = TCPMule(None)
    controller = MuleController()
    path_controller = PathController()

    path_controller.add_segment(PathSegment( 0.1, 4, 2))
    path_controller.add_segment(PathSegment( 0.0, 4, 5))
    path_controller.add_segment(PathSegment(-0.1, 4, 2))
    path_controller.add_segment(PathSegment( 0.0, 4, 5))
    path_controller.add_segment(PathSegment( 0.1, 4, 2))
    path_controller.add_segment(PathSegment( 0.0, 4, 5))
    path_controller.add_segment(PathSegment( 0.0, 0, 5))

    for timestep, _ in enumerate(mule.run()):
        path_controller.update(controller)
        controller.update(mule)
