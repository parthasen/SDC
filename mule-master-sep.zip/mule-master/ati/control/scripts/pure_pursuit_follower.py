import asyncio
import math
import sys
import os

from google.protobuf import text_format

sys.path.append(os.path.abspath('.'))

import ati.schema as schema

from ati.control.low_control import WheelController
from ati.odometry import Odometry
from ati.service import Service
from ati.control.pid import PID

import scipy.interpolate as interpolate
import numpy as np

def pure_pursuit(position, angle, anchor):
    anchor = anchor - position[:2]
    angle = math.pi/2 - angle

    rot = np.asarray([[np.cos(angle), -np.sin(angle)], [np.sin(angle), np.cos(angle)]])

    anchor = np.dot(rot, anchor)

    return (anchor[0]**2 + anchor[1]**2)/(2 * anchor[0])

class SimpleCourse(Service):
    dependencies = [Odometry]

    async def run(self):
        waypoint = None

        controller = WheelController()

        controller.desired_velocity = 4.

        phi_controller = PID(1, 0, 0)

        timesteps = self.sub.subscribe("mule.vehicle.timestep")
        road_source = self.sub.subscribe("mule.perception.roads")

        while True:
            timestep, roads = await asyncio.gather(timesteps.get(), road_source.get())

            if len(roads.lanes[0].areas) == 0:
                self.pub.send("mule.vehicle.controls", schema.VehicleControls(BrakeInput=1))

                print("ARRIVED!")

                return

            v = self.odometry.velocity[1]

            theta = self.odometry.rotation[2]

            lookahead = 20 / 20
            vx = self.odometry.position[0] + v * math.cos(theta) * lookahead
            vy = self.odometry.position[1] + v * math.sin(theta) * lookahead

            waypoint = self.pure_pursuit_anchor(roads, vx, vy)

            # print(waypoint)

            magnitude, phi_e = self.calculate_error(waypoint)

            r = pure_pursuit(self.odometry.position, theta, waypoint)

            controller.desired_omega = min(
                v/r,
                # phi_controller.update(phi_e), 
                8/controller.desired_velocity # a_y / v gives you max omega
            )

            # print(phi_e, controller.desired_omega)
            await self.pub.send("mule.vehicle.controls", controller.update(self.odometry))

    def fit_road_spline(self, roads):
        cxs = np.zeros(len(roads.lanes[0].areas))
        cys = np.zeros(len(roads.lanes[0].areas))

        for index, patch in enumerate(roads.lanes[0].areas):
            cxs[index], cys[index] = self.polygon_center(patch)

        if len(cxs) <= 2:
            return cxs[-1], cys[-1], None, "straight"

        # print(cxs, cys)

        minx, miny, maxx, maxy = np.min(cxs), np.min(cys), np.max(cxs), np.max(cys)

        if (maxx - minx) > (maxy - miny):
            order = np.argsort(cxs)

            cxs = cxs[order]
            cys = cys[order]

            road_spline = interpolate.CubicSpline(cxs, cys)

            return minx, maxx, road_spline, "x"
        else:
            order = np.argsort(cys)

            cxs = cxs[order]
            cys = cys[order]

            road_spline = interpolate.CubicSpline(cys, cxs)

            return miny, maxy, road_spline, "y"

        # road_spline = interp1d(cxs, cys, kind='cubic')
        # road_spline = interpolate.Akima1DInterpolator(cxs, cys)
        # road_spline = interpolate.CubicSpline(cxs, cys)

    def pure_pursuit_anchor(self, roads, vx, vy):
        spline_min, spline_max, spline, direction = self.fit_road_spline(roads)

        num = (spline_max - spline_min) * 10

        if direction == "x":
            xs = np.linspace(spline_min, spline_max, num=num, endpoint=True)
            ys = spline(xs)
        elif direction == "straight":
            return spline_min, spline_max
        else:
            ys = np.linspace(spline_min, spline_max, num=num, endpoint=True)
            xs = spline(ys)

        closest_point = np.argmin(np.square(xs - vx) + np.square(ys - vy))

        return xs[closest_point], ys[closest_point]

    def calculate_error(self, waypoint):
            x_diff = waypoint[0] - self.odometry.position[0]
            y_diff = waypoint[1] - self.odometry.position[1]

            magnitude = math.sqrt(x_diff ** 2 + y_diff ** 2)

            phi_e = self.odometry.rotation[2] - math.atan2(y_diff, x_diff)

            phi_e = math.atan2(math.sin(phi_e), math.cos(phi_e))

            return magnitude, phi_e

    def polygon_center(self, polygon):
        cx = 0
        cy = 0
        a = 0

        for i in range(0, len(polygon.edges)):
            if i == len(polygon.edges) - 1:
                xn = polygon.edges[0].x
                yn = polygon.edges[0].y
            else:
                xn = polygon.edges[i + 1].x
                yn = polygon.edges[i + 1].y

            x = polygon.edges[i].x
            y = polygon.edges[i].y

            cx += (x + xn) * (x * yn - xn * y)
            cy += (y + yn) * (x * yn - xn * y)
            a  += x * yn - xn * y

        a *= 0.5

        cx /= 6*a
        cy /= 6*a

        return [cx, cy]

if __name__ == '__main__':
    SimpleCourse()
