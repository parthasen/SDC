from .road_polygons import sharp_curve_ll, sharp_curve_rl, bend_left_ll, bend_left_rl
from .road_polygons import straight_ll, straight_rl, deadend, curve_ll, curve_rl
from .road_polygons import bend_right_ll, bend_right_rl

import ati.schema as schema
import numpy as np

road_mapping = {
    "straight": (straight_ll, straight_rl),
    "deadend": (deadend, deadend),
    "curve": (curve_ll, curve_rl),
    "sharpCurve": (sharp_curve_ll, sharp_curve_rl),
    "bendLeft": (bend_left_ll, bend_left_rl),
    "bendRight": (bend_right_ll, bend_right_rl),
}

middle_mapping = {
    "curve": [4.686296, -11.313714],
    "sharpCurve": [2.34314576, -5.656854]
}

minus45 = np.asarray([
    [np.cos(-np.pi/4), np.sin(-np.pi/4)], 
    [-np.sin(-np.pi/4), np.cos(-np.pi/4)]
])

def generate_polygons(vehicle_position, vehicle_angle, roads, container, lane_idx=0):
    lane = container.lanes.add()

    vehicle_angle = np.deg2rad(vehicle_angle)
    vehicle_direction = (np.sin(vehicle_angle), np.cos(vehicle_angle))

    for road in roads:
        tx, _, ty  = road["pos"]
        _, angle, _ = road["rot"]

        ulane_idx = lane_idx

        angle = np.deg2rad(angle)
        rot = np.asarray([[np.cos(angle), np.sin(angle)], [-np.sin(angle), np.cos(angle)]])

        road_direction = np.dot(rot, (0, 1))

        if road["type"] in middle_mapping:
            end_position = np.asarray([tx, ty])
            middle_position = np.dot(rot, middle_mapping[road["type"]]) + end_position

            distance_end = np.linalg.norm(vehicle_position - end_position)
            distance_middle = np.linalg.norm(vehicle_position - middle_position)

            if distance_middle < distance_end:
                road_direction = np.dot(minus45, road_direction)

        if np.dot(vehicle_direction, road_direction) < 0:
            ulane_idx = ulane_idx ^ 1

        r = road_mapping[road["type"]][ulane_idx]

        for face in r:
            polygon = lane.areas.add()

            for x, y in face:
                edge = polygon.edges.add()
                edge.x, edge.y = np.dot(rot, [-x, y]) + [tx, ty]

    return lane
