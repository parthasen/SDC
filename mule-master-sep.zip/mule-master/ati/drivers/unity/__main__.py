from .bridge import TCPMule

TCPMule()
