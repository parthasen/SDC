from .utils import setup_logger, get_class

import sys

logger = setup_logger('ati')

class Mule(object):
    def __init__(self, config):
        self.config = config

        self.initialize_drivers()
        self.initialize_services()

    def initialize_drivers(self):
        for driver_name, info in self.config['drivers'].items():
            if 'classpath' not in info:
                logger.error("Invalid config - driver {} does not have classpath".format(driver_name))

                sys.exit(1)

            classpath = info['classpath']
            arguments = info['arguments'] if 'arguments' in info else []

            logger.debug("Starting {} with arguments {}".format(classpath, arguments))

            driver = get_class(classpath)(arguments)

            logger.info("Initializing driver {}".format(driver_name))

            driver.initialize()
            driver.start()

            logger.info("Driver {} loaded".format(driver_name))

            setattr(self, driver_name, driver)

    def initialize_services(self):
        services = []

        for service_name, info in self.config['services'].items():
            if 'classpath' not in info:
                logger.error("Invalid config - service {} does not have classpath".format(service_name))

                sys.exit(1)

            classpath = info['classpath']
            arguments = info['arguments'] if 'arguments' in info else []

            logger.debug("Starting {} with arguments {}".format(classpath, arguments))

            service = get_class(classpath)(self, arguments)

            logger.info("Initializing Service {}".format(service_name))

            service.initialize()

            logger.info("Service {} loaded".format(service_name))

            setattr(self, service_name, service)

            services.append(service)

        for service in services:
            service.start()
