package main

import (
	"ati/schema"
	zmq "github.com/pebbe/zmq4"

	"log"
	"os"
)

func main() {
	log.SetPrefix("[debug_log] ")

	sub := os.Getenv("ATI_SUB")

	socket, _ := zmq.NewSocket(zmq.SUB)
	defer socket.Close()

	if err := socket.Connect(sub); err != nil {
		log.Fatalf("Unable to open SUB socket at %s: %s", sub, err)
	}

	socket.SetSubscribe("mule")

	for {
		packet, _ := socket.RecvBytes(0)

		topic, message, err := schema.DecodeMessage(packet)

		if err != nil {
			log.Fatalf("Unable to decode message: %s", err)
		}

		log.Printf("%s: message %#v", topic, message)
	}
}
