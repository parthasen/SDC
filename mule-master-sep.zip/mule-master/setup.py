from setuptools import setup, find_packages

setup(
    name='ati',
    version='1.0.0',
    packages=find_packages(exclude=['experiments', 'tests']),

    install_requires=[
        "numpy==1.13.1",
        "protobuf==3.4.0",
        "pyzmq==16.0.2",
        "scipy==0.19.1",
    ],

    extras_require={
        'dev': [
            'pytest==3.2.1', 
            'pytest-cov==2.5.1',
            "coverage==4.4.1",
        ],
    },

    entry_points={
        'console_scripts': [
            'unity_driver=ati.drivers.unity.bridge:TCPMule',
            'control_simple_course=ati.control.scripts.simple_course:SimpleCourse',
            'control_pure_pursuit_follower=ati.control.scripts.pure_pursuit_follower:SimpleCourse',
        ],
    },
)
